"""Generate offline 48 kHz PCM24 foley candidates from fixed, reproducible recipes."""
import json
import hashlib

import numpy as np
import scipy.signal as sig
import soundfile as sf

from comfy_jobs import ROOT, save

RATE = 48000
OUT=ROOT/"runs/audio"
OUT.mkdir(parents=True,exist_ok=True)
rng=np.random.default_rng(20261115)

def n(sec):
    return int(RATE*sec)

def colored(length,lo,hi):
    source=rng.standard_normal(length)
    if lo==0:
        sos=sig.butter(2,hi,fs=RATE,btype="lowpass",output="sos")
    else:
        sos=sig.butter(2,[lo,hi],fs=RATE,btype="bandpass",output="sos")
    return sig.sosfilt(sos,source)

def tone(sec,frequencies,tau):
    t=np.arange(n(sec))/RATE
    x=sum(amplitude*np.sin(2*np.pi*h*t) for h,amplitude in frequencies)
    return x*np.exp(-t/tau)

def strike(dur,tau,lo,hi):
    t=np.arange(n(dur))/RATE
    return colored(n(dur),lo,hi)*np.exp(-t/tau)

def layer(dst,pcm,start,gain=1):
    i=n(start)
    count=min(len(pcm),len(dst)-i)
    if count>0:
        dst[i:i+count]+=pcm[:count]*gain

def fade(x,in_ms=4,out_ms=35):
    a,b=n(in_ms/1000),n(out_ms/1000)
    x[:a]*=np.linspace(0,1,a)
    x[-b:]*=np.linspace(1,0,b)
    return x

def stereo(x,room=0.11):
    y=x.copy()
    delayed=n(.017)
    y[delayed:]+=x[:-delayed]*room
    return np.column_stack((x,y))

def stable_loop(a,overlap=1.1):
    width=n(overlap)
    tail=a[-width:].copy()
    w=(1-np.cos(np.linspace(0,np.pi,width)))/2
    a[:width]=tail*(1-w)+a[:width]*w
    return a[:-width]

def ambiance(mode):
    length=n(9.1)
    x=colored(length,25,96)*.037+colored(length,97,310)*.012+colored(length,300,1800)*.002
    t=np.arange(length)/RATE
    if mode==2:
        x+=colored(length,2100,9200)*.057+colored(length,600,2700)*.021
        for off in rng.uniform(.6,8.5,60):
            layer(x,strike(.025,.004,1900,9800),off,rng.uniform(.01,.05))
    else:
        x+=.008*np.sin(2*np.pi*60*t)+.003*np.sin(2*np.pi*120*t)
        for off in (2.4, 4.6, 7.1):
            layer(x,strike(.30,.075,75,430),off,.034 if mode==3 else .05)
        if mode==1:
            layer(x,strike(.24,.05,450,2200),5.6,.013)
    width=n(.017)
    return np.column_stack((stable_loop(x.copy()),stable_loop(np.roll(x,width)*.86)))


def applause():
    length = 2.8
    x=np.zeros(n(length))
    for off in rng.uniform(.08,2.55,130):
        clap=strike(.103,.024,330,5300)
        layer(x,clap,off,.27*rng.uniform(.25,1)*max(.03,(1-off/2.8)**.9))
    for off,fq in ((.2,580),(.38,716),(.56,480)):
        t=np.arange(n(0.65))/RATE
        cheer=np.sin(2*np.pi*(fq*t+20*np.sin(t*6)))*np.sin(np.pi*t/.65)**2
        layer(x,cheer,off,.023)
    return fade(x,45,280)

def knocks(count):
    x=np.zeros(n(1.0))
    for i in range(count):
        impact = strike(.15,.022,150,3800)*.13
        impact+=tone(.15,[(148,.37),(284,.19),(390,.10)],.027)
        layer(x,impact,.14+i*.28,1-.1*i)
    return fade(x)

def rustle(count,spread):
    x=np.zeros(n(1.65))
    for i in range(count):
        dur=.24+.025*i
        t=np.arange(n(dur))/RATE
        sound=colored(n(dur),520,8200)*np.sin(np.pi*t/dur)**2
        layer(x,sound,.17+i*spread,.30)
        layer(x,strike(.095,.022,360,3200),.28+i*spread,.12)
    return fade(x)

def umbrella():
    x=np.zeros(n(1.35))
    duration=.43
    t=np.arange(n(duration))/RATE
    fabric=colored(n(duration),300,4400)*np.sin(np.pi*t/duration)**1.7
    layer(x,fabric,.18,.23)
    layer(x,strike(.13,.028,140,1800),.51,.16)
    click=strike(.08,.012,480,8900)+tone(.08,[(1940,.13),(2480,.08)],.013)
    layer(x,click,.62,.35)
    return fade(x)

sources={"AU01":ambiance(1),"AU02":ambiance(2),"AU03":ambiance(3),"AU04":applause(),
         "AU05":knocks(1),"AU06":knocks(2),"AU07a":rustle(3,.166),
         "AU07b":rustle(3,.29),"AU07c":umbrella()}
for key,x in sources.items():
    peak=np.max(np.abs(x))
    target=.19 if key in ("AU01","AU02","AU03") else .58
    x=(target/peak)*x
    path=OUT/(key+".wav")
    sf.write(path,x,RATE,subtype="PCM_24")
    save(OUT/(key+".json"),{"method":"fixed procedural foley","script":"tools/render_local_foley.py",
         "seed":20261115,"id":key,"seconds":len(x)/RATE,"channels":x.shape[1] if x.ndim==2 else 1,
         "sha256":hashlib.sha256(path.read_bytes()).hexdigest(),"peak_dbfs":20*np.log10(target)})

