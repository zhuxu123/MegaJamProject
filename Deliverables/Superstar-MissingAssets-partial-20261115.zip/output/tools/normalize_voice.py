"""Normalize the two authorized Chinese voice lines to the delivery WAV format."""
import hashlib
from math import gcd
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy.signal import resample_poly

from comfy_jobs import ROOT, save

path=ROOT/"runs/audio"
lines={"AU09":"切广告","AU10":"取消林晚资格"}
for key,line in lines.items():
    source=path/(key+"-sapi.wav")
    pcm,rate=sf.read(source)
    if pcm.ndim==2:
        pcm=pcm.mean(axis=1)
    div=gcd(48000,rate)
    aligned=resample_poly(pcm,48000//div,rate//div)
    peak=np.max(np.abs(aligned))
    assert peak>0
    aligned=.67*aligned/peak
    dest=path/(key+".wav")
    sf.write(dest,aligned,48000,subtype="PCM_24")
    save(path/(key+".json"),{"engine":"Microsoft Speech SAPI","voice":"Microsoft Kangkang",
         "culture":"zh-CN","spoken_text":line,"rate":1,"volume":90,"script":"tools/normalize_voice.py",
         "source":source.relative_to(ROOT).as_posix(),"source_sha256":hashlib.sha256(source.read_bytes()).hexdigest(),
         "sha256":hashlib.sha256(dest.read_bytes()).hexdigest(),"duration":len(aligned)/48000,
         "source_rate":rate,"final_rate":48000})

