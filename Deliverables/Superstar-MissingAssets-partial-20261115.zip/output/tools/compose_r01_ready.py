"""Compose the intact photo and adhesive tab into Lin Wan's existing grip."""
import hashlib

from PIL import Image

from comfy_jobs import ROOT, read, save

id = "R01_linwan_peel_label"
src = ROOT / "runs/pose-prep" / id / "source_000040.png"
image = Image.open(src).convert("RGB")
photo_path = ROOT / "output/static/P07_photo_intact.png"
photo = Image.open(photo_path).convert("RGBA").crop((145, 86, 368, 423))
photo = photo.resize((34, 50), Image.Resampling.LANCZOS)
# Keep the hand pixels in front. The old photo silhouette serves as the planar guide.
origin = (384, 162)
base = image.copy()
base.paste(photo, origin, photo)
for y in range(178, 212):
    for x in range(380, 423):
        r, g, b = image.getpixel((x, y))
        if r > 163 and r > g + 11 and g > b + 12:
            base.putpixel((x, y), (r, g, b))
base.save(ROOT / "inputs" / f"{id}.png")
save(ROOT / "runs/pose-prep" / id / "composite_first_frame.json", {
    "photograph": photo_path.relative_to(ROOT).as_posix(),
    "photograph_sha256": hashlib.sha256(photo_path.read_bytes()).hexdigest(),
    "source": src.relative_to(ROOT).as_posix(),
    "source_sha256": hashlib.sha256(src.read_bytes()).hexdigest(),
    "photo_position": list(origin),
    "photo_size": [34, 50],
    "hand_occlusion": "retained existing warm flesh pixels within both hand bounds",
})

