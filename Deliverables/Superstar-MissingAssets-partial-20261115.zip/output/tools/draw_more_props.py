"""Draw remaining exact-count and safety-prop variants."""
from PIL import ImageDraw
from comfy_jobs import save
from draw_continuity_props import canvas, poly, line, box, polish, OUT, SCALE


def folder():
    im=canvas()
    d=ImageDraw.Draw(im)
    ed="#5d606b"
    poly(d,[(91,330),(105,163),(244,163),(266,183),(410,183),(424,331)],"#9097a7",ed,3)
    for x,y,shade in [(118,138,"#eee4cf"),(133,149,"#f2e8d2"),(148,162,"#fff3d6")]:
        poly(d,[(x,y),(x+216,y+7),(x+220,y+134),(x+2,y+128)],shade,"#9c9585",2)
    poly(d,[(87,216),(423,207),(412,343),(105,355)],"#a6a8af",ed,3)
    line(d,[(103,228),(404,218)],"#c5c5ca",4)
    return polish(im,"P06_document_folder",{"grip":[95,270],"paper_opening":[256,213]})


def papers():
    im=canvas()
    d=ImageDraw.Draw(im)
    sheets=[[(86,150),(208,134),(230,300),(108,317)],
            [(280,98),(404,118),(375,289),(253,267)],
            [(204,305),(332,334),(312,420),(188,397)]]
    for i,vertices in enumerate(sheets):
        poly(d,vertices,["#f7edda","#f5e9d2","#fff3dc"][i],"#a1947f",2)
        x,y=vertices[0]
        line(d,[(x+3,y+5),(vertices[1][0]-5,vertices[1][1]+6)],"#fff9ed",2)
    return polish(im,"P09_three_papers",{"sheet_grips":[[103,168],[293,118],[219,328]]})


def stand():
    im=canvas()
    d=ImageDraw.Draw(im)
    ed="#33323c"
    poly(d,[(142,355),(347,355),(377,385),(181,400),(132,375)],"#52515e",ed,4)
    poly(d,[(224,311),(293,177),(322,180),(280,367),(245,366)],"#454555",ed,4)
    poly(d,[(283,177),(301,178),(263,345),(244,345)],"#7b7987",ed,3)
    poly(d,[(178,348),(283,348),(280,372),(175,374)],"#62616f",ed,4)
    line(d,[(180,347),(277,347)],"#9d9ba8",3)
    return polish(im,"P10_phone_stand",{"cradle":[235,351],"footprint":[259,389]})


def theater_prop():
    im=canvas()
    d=ImageDraw.Draw(im)
    ed="#4d4b5a"
    poly(d,[(200,279),(205,159),(213,137),(226,123),(245,119),(263,121),
            (275,132),(277,148),(274,243),(268,272)],"#c2c6d0",ed,4)
    poly(d,[(203,263),(208,160),(217,140),(235,127),(246,125),(233,148),
            (226,169),(222,259)],"#e2e4ed")
    d.rounded_rectangle(box((199,277,269,405)), radius=20*SCALE,fill="#403d4b",outline=ed,width=3*SCALE)
    d.rounded_rectangle(box((192,263,278,281)), radius=6*SCALE,fill="#514e60",outline=ed,width=3*SCALE)
    line(d,[(216,296),(214,377)],"#777386",5)
    return polish(im,"P04_prop_knife",{"grip":[234,336],"rounded_tip":[245,120]})


if __name__ == "__main__":
    save(OUT / "more_assets.json", {
        "P04_prop_knife":theater_prop(), "P06_document_folder":folder(),
        "P09_three_papers":papers(), "P10_phone_stand":stand(),
    })

