"""Use the installed PyAV runtime for source PTS and RGB frame decoding."""
import sys
from fractions import Fraction

import av
import numpy as np

import export_animation


def probe(video):
    with av.open(str(video)) as container:
        stream = container.streams.video[0]
        rate = stream.average_rate
        duration = float(stream.duration * stream.time_base) if stream.duration is not None else 0
        times = [float(frame.pts * frame.time_base) for frame in container.decode(stream)]
        width, height = stream.width, stream.height
    if not times or any(b <= a for a, b in zip(times, times[1:])):
        raise ValueError("Missing or non-increasing video timestamps")
    origin = times[0]
    relative = [time - origin for time in times]
    step = float(np.median(np.diff(relative))) if len(relative) > 1 else 1 / float(rate or 24)
    return {"times": relative, "source_pts_origin": origin,
            "duration": max(duration, relative[-1] + step), "width": width, "height": height,
            "avg_frame_rate": str(rate or Fraction(0, 1))}


def decode(video):
    with av.open(str(video)) as container:
        for frame in container.decode(video=0):
            yield frame.to_ndarray(format="rgb24")


if __name__ == "__main__":
    export_animation.probe = probe
    export_animation.decode = decode
    sys.exit(export_animation.main())

