"""Compose EV03 using actual portraits and the existing backstage scene."""
import base64
import hashlib
import io
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageOps

from comfy_jobs import ROOT, save

OUT = ROOT / "runs/evidence/EV03_roster"
OUT.mkdir(parents=True,exist_ok=True)
scene = ROOT / "references/scenes/dressing.png"
portrait_ids = ("S01_linwan_idle","S02_xiaobei_idle","S03_suyao_idle")
portraits = [ROOT / "references/baseline" / id / "first.png" for id in portrait_ids]
label_font = ImageFont.truetype(r"C:\Windows\Fonts\msyh.ttc",26)
scene_image = ImageOps.fit(Image.open(scene).convert("RGB"),(1280,720))
scene_image.save(OUT/"source_scene_1280.jpg", quality=94)
image = scene_image.convert("RGBA")
overlay = Image.new("RGBA",image.size,(18,21,34,47))
image.alpha_composite(overlay)
d = ImageDraw.Draw(image)
art = ["<rect width='1280' height='720' fill='#121522' opacity='.184'/>"]
def raster(im,x,y,w,h):
    b = io.BytesIO()
    im.save(b,format="PNG")
    return f"<image x='{x}' y='{y}' width='{w}' height='{h}' href='data:image/png;base64,{base64.b64encode(b.getvalue()).decode()}'/>"

def rect(coords,r,fill,stroke=None,stroke_width=1):
    x,y,x2,y2=coords
    d.rounded_rectangle(coords,radius=r,fill=fill,outline=stroke,width=stroke_width)
    art.append(f"<rect x='{x}' y='{y}' width='{x2-x}' height='{y2-y}' rx='{r}' fill='{fill}'"
               f" stroke='{stroke or 'none'}' stroke-width='{stroke_width}'/>")

rect((156,141,1124,630),16,"#202532")
rect((153,126,1110,611),16,"#76717d","#ccc0ab",4)
names=("林晚","小北","苏瑶","其他选手")
for i,name in enumerate(names):
    x=190+225*i
    art.append(f"<g id='contestant-{i+1}'>")
    rect((x,166,x+205,560),8,"#e8dfcb","#b8aa95",3)
    rect((x+14,181,x+191,507),4,"#8c9cb1")
    if i<3:
        im=Image.open(portraits[i]).convert("RGBA")
        im=im.crop(im.getchannel("A").getbbox())
        h=298
        im=im.resize((round(im.width*h/im.height),h),Image.Resampling.LANCZOS)
        xy=(x+(205-im.width)//2,192)
        image.alpha_composite(im,xy)
        art.append(raster(im,*xy,im.width,im.height))
    else:
        d.ellipse((x+65,239,x+140,314),fill="#e1dfdf")
        rect((x+35,321,x+170,453),33,"#c2c7d0")
        art.append(f"<circle cx='{x+102.5}' cy='276.5' r='37.5' fill='#e1dfdf'/>")
    d.text((x+102,532),name,font=label_font,anchor="mm",fill="#262733")
    art.append(f"<text x='{x+102}' y='542' text-anchor='middle' font-family='Microsoft YaHei' "
               f"font-size='26' fill='#262733'>{name}</text>")
    if i!=2:
        d.line([(x+27,205),(x+175,480)],fill=(169,46,55),width=15)
        d.line([(x+176,205),(x+28,480)],fill=(169,46,55),width=15)
        art.append(f"<path d='M{x+27},205 L{x+175},480 M{x+176},205 L{x+28},480' "
                   "fill='none' stroke='#a92e37' stroke-width='15'/>")
    art.append("</g>")
image.convert("RGB").save(OUT/"EV03_roster.png")
layer_text = ("<svg xmlns='http://www.w3.org/2000/svg' width='1280' height='720' viewBox='0 0 1280 720'>"
              "<g id='existing-scene'>"+raster(scene_image,0,0,1280,720)+"</g>"+
              "".join(art)+"</svg>")
(OUT/"EV03_roster.editable.svg").write_text(layer_text,encoding="utf-8")
refs = [scene,*portraits]
save(OUT/"layout_workflow.json",{
    "renderer":"Pillow, editable SVG sidecar", "script":"tools/compose_roster.py",
    "original_set":"existing dressing/backstage reference", "labels":list(names),
    "marked_slots":[1,2,4],"unmarked_slots":[3],
    "references":[{"path":ref.relative_to(ROOT).as_posix(),"sha256":hashlib.sha256(ref.read_bytes()).hexdigest()} for ref in refs],
})

