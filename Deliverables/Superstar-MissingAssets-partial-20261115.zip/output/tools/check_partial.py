"""Assemble a truthful partial delivery by checking only the actual reviewed files."""
import hashlib
import json
import shutil
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from PIL import Image

from comfy_jobs import ROOT, read, save, request

out = ROOT / "output"
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def validate():
    jobs = read(ROOT/"config/jobs.json")
    static = read(ROOT/"config/static_jobs.json")
    audio = read(ROOT/"config/audio_jobs.json")
    approvals = read(ROOT/"config/final_reviews.json")
    stills = read(out/"static_reviews.json")
    generation = read(out/"generation_manifest.json")["items"]
    completed = dict(animation=[], static=[], audio=[])
    for task in jobs:
        id=task["id"]
        if approvals.get(id,{}).get("approved") is not True:
            continue
        folder = out/"animations"/id
        meta=read(folder/"animation.json")
        assert meta["id"]==id and meta["fps"]==5 and meta["canvas"]==[640,640],id
        assert meta["anchor_pixels"]==[320,570] and meta["loop"] is task["loop"],id
        assert meta["source_sha256"]==sha(ROOT/meta["source"]),id
        assert set(task["events"]) <= set(meta["events"]),id
        assert len(meta["frame_mapping"])==meta["frame_count"],id
        assert list(sorted({m["source_frame"] for m in meta["frame_mapping"]}))==[m["source_frame"] for m in meta["frame_mapping"]],id
        for i,m in enumerate(meta["frame_mapping"],1):
            assert m["file"]==f"frames/{id}_{i:06d}.png" and m["output_seconds"]==(i-1)/5,id
            with Image.open(folder/m["file"]) as png:
                assert png.mode=="RGBA" and png.size==(640,640) and png.getchannel("A").getextrema()==(0,255),(id,i)
        with Image.open(folder/"preview_5fps.gif") as gif:
            assert gif.n_frames==meta["frame_count"],id
            for i in range(gif.n_frames):
                gif.seek(i)
                assert gif.info["duration"]==200,(id,i)
        assert id in generation
        completed["animation"].append(id)
    for task in static:
        id=task["id"]
        if not stills.get(id,{}).get("approved"):
            continue
        assert all(stills[id][k] for k in ("approved","identity_and_style","alpha_or_background","content_matches_script")), id
        with Image.open(ROOT/task["output"]) as png:
            assert list(png.size)==task["canvas"], id
            if task["alpha"]:
                assert png.mode=="RGBA" and png.getchannel("A").getextrema()==(0,255),id
        assert id in generation
        completed["static"].append(id)
    q=request("http://127.0.0.1:8188","/queue")
    active = {}
    for key in ("queue_running","queue_pending"):
        for record in q[key]:
            name=next((node["inputs"]["filename_prefix"] for node in record[2].values()
                       if "filename_prefix" in node["inputs"]),"")
            if name.startswith(("video/superstar/","superstar_missing/")):
                active[record[1]]={"queue":key,"prefix":name}
    summary={
        "as_of":datetime.now(timezone.utc).isoformat(),"delivery_status":"PARTIAL",
        "completed":completed,
        "remaining":{k:[j["id"] for j in cls if j["id"] not in completed[k]] for k,cls in
                     (("animation",jobs),("static",static),("audio",audio))},
        "queue":active,
        "reuse_pending":read(ROOT/"config/reuse_existing.json")["reuse_not_regenerate"],
        "sync_pending":[j["id"] for j in read(ROOT/"integration/sync_groups.json")],
        "unwritten_dialogue":read(ROOT/"config/deferred.json"),
    }
    save(out/"work_status.json",summary)
    for k,jobs in completed.items():
        print(k,len(jobs),"/",len(jobs)+len(summary["remaining"][k]))
    return summary

if __name__=="__main__":
    validate()

