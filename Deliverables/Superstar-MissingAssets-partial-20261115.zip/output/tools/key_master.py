"""Fit local master illustrations to the common green-screen registration."""
import argparse
import hashlib
import shutil

import cv2
import numpy as np
from PIL import Image, ImageOps

from comfy_jobs import ROOT, read, save


def prep(folder, key):
    raw = Image.open(folder / "source.png").convert("RGB")
    rgb = np.asarray(raw).astype(np.float32)
    g = rgb[:, :, 1]
    chroma = g - np.maximum(rgb[:, :, 0], rgb[:, :, 2])
    default = float(np.median(chroma[:, :32]))
    mask = np.clip((default * .50 - chroma) / (default * .42), 0, 1)
    # Any contact shadow stays green-dominant. Limit the mask to the main connected subject.
    count, labels, stats, _ = cv2.connectedComponentsWithStats(np.uint8(mask > .15))
    if count < 2:
        raise ValueError("No subject")
    main = int(np.argmax(stats[1:, cv2.CC_STAT_AREA])) + 1
    mask *= labels == main
    alpha = Image.fromarray(np.rint(mask*255).astype(np.uint8))
    bounds = alpha.point(lambda a: 255 if a > 140 else 0).getbbox()
    fg = raw.convert("RGBA")
    fg.putalpha(alpha)
    fg = fg.crop(bounds)
    if key in ("REF_chenmo", "REF_actress", "REF_xiaoxia", "REF_man"):
        fg = ImageOps.mirror(fg)
    fg = fg.resize((round(fg.width * 478 / fg.height), 478), Image.Resampling.LANCZOS)
    base = Image.new("RGB", (640,640), (0,255,0))
    base.paste(fg,(320-fg.width//2,92),fg)
    base.save(folder / "master_candidate.png")


def promote(folder, key, notes):
    candidate = folder / "master_candidate.png"
    out = ROOT / "output"
    target = out / "masters" / f"{key}.png"
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():
        raise FileExistsError(target)
    shutil.copyfile(candidate, target)
    role = key.removeprefix("REF_")
    identity = ROOT / "runs/identity-prep" / f"{role}-identity.png"
    identity.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(candidate, identity)
    rr = out / "static_reviews.json"
    reviews = read(rr) if rr.exists() else {}
    reviews[key] = {
        "approved": True, "identity_and_style": True, "alpha_or_background": True,
        "content_matches_script": True, "notes": notes,
        "design_status": "production_draft_not_user_approved", "reviewer": "Codex",
    }
    save(rr,reviews)
    mf = out / "generation_manifest.json"
    result = read(mf) if mf.exists() else {"items":{}}
    record = read(folder / "record.json")
    ref = ROOT / "references/linwan.jpg"
    rel = lambda path: path.relative_to(ROOT).as_posix()
    result["items"][key] = {
        "model": "Z-Image-Turbo bf16 with Qwen 3 4B and ae.safetensors; ComfyUI 0.30.2",
        "workflow": rel(folder / "submitted_api.json"),
        "references": [{"path": rel(ref), "sha256": hashlib.sha256(ref.read_bytes()).hexdigest(),
                        "role": "visually compared style reference; text-only image graph"}],
        "seed": record["seed"], "attempts": int(folder.name.split("_")[-1]),
        "source_files": list(map(rel,[folder / "source.png",folder / "record.json",folder / "history.json",
                                     ROOT / "tools/key_master.py"])),
    }
    save(mf,result)


def main():
    p=argparse.ArgumentParser()
    p.add_argument("mode", choices=["prep","promote"])
    p.add_argument("key")
    p.add_argument("attempt", type=int)
    p.add_argument("--notes",default="")
    a=p.parse_args()
    folder=ROOT / "runs/static" / a.key / f"attempt_{a.attempt:02d}"
    if a.mode=="prep":
        prep(folder,a.key)
    else:
        promote(folder,a.key,a.notes)
if __name__=="__main__":
    main()


