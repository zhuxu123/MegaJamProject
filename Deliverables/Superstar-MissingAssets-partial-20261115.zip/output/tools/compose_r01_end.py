from PIL import Image
from comfy_jobs import ROOT, read, save

job = "R01_linwan_peel_label"
raw = Image.open(ROOT / "runs/pose-prep" / job / "source_000094.png").convert("RGB")
card = Image.open(ROOT / "output/static/P07_photo_intact.png").convert("RGBA").crop((145,86,368,423))
# Cover the attached label with the original portrait backdrop before placing the full card.
from PIL import ImageDraw
draw=ImageDraw.Draw(card)
draw.rectangle((101,6,207,14), fill="#f4ebd4")
draw.rectangle((101,15,207,45), fill="#9dabc7")
card = card.resize((35,50),Image.Resampling.LANCZOS)
tab = Image.open(ROOT / "output/static/P08_old_label.png").convert("RGBA")
tab = tab.crop(tab.getchannel("A").getbbox()).resize((16,6),Image.Resampling.LANCZOS)
target = raw.copy()
for y in range(157,214):
    for x in range(370,450):
        r,g,b=raw.getpixel((x,y))
        # Existing torn fragments are neutral purple, darker than the warm skin.
        if (abs(r-b)<32 and abs(g-b)<36) or (min(r,g,b)>180 and max(r,g,b)-min(r,g,b)<58):
            target.putpixel((x,y),(0,255,0))
target.paste(card,(407,161),card)
target.paste(tab,(357,186),tab)
for y in range(177,221):
    for x in range(365,454):
        r,g,b=raw.getpixel((x,y))
        if r>157 and r>g+14 and g>b+9:
            target.putpixel((x,y),(r,g,b))
target.save(ROOT/"runs"/job/"last_frame_attempt_02.png")
save(ROOT/"runs"/job/"photo_end_composite.json", {"source_frame":94, "photo_origin":[407,161],
    "tab_origin":[357,186], "source":"runs/pose-prep/"+job+"/source_000094.png"})


