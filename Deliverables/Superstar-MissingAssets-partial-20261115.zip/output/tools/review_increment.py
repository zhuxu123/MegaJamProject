"""Record measured cuts and promote only explicitly reviewed assets."""
import argparse
import hashlib
import shutil
from pathlib import Path
from types import SimpleNamespace

from comfy_jobs import ROOT, read, save, job_by_id
import export_animation
from export_with_av import decode, probe
from repair_matte import edge_matte


def dig(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def cut(id, source_attempt, start, end, events):
    task = job_by_id(id)
    folder = ROOT / "runs" / id / f"attempt_{source_attempt:02d}"
    src = folder / "source.mp4"
    pts = probe(src)["times"]
    if len(events) != len(task["events"]) or not 1 <= start < end <= len(pts):
        raise ValueError("Invalid measured frames for this task.")
    if any(not start <= frame < end for frame in events):
        raise ValueError("Event is outside the selected interval.")
    data = {"video": src.relative_to(ROOT).as_posix(), "reviewed": True,
            "start_seconds": pts[start-1], "end_seconds_exclusive": pts[end-1], "loop": task["loop"],
            "event_times": {name: pts[n-1] for name,n in zip(task["events"],events)}}
    export_animation.probe = probe
    export_animation.decode = decode
    export_animation.remove_green = edge_matte
    export_animation.export(task, data, folder / "candidate",
                            SimpleNamespace(foreground=24, background=193, feather=0, despill=1))


def promote(id, source_attempt, facing, notes):
    task = job_by_id(id)
    folder = ROOT / "runs" / id / (f"attempt_{source_attempt:02d}" if source_attempt else "baseline_repair")
    candidate = folder / "candidate" if source_attempt else ROOT / "runs" / "repair-candidates" / id
    meta = read(candidate / "animation.json")
    out = ROOT / "output" / "animations" / id
    shutil.copytree(candidate, out)
    if task["kind"] == "expression":
        shutil.copy2(out / meta["frame_mapping"][0]["file"], out / "expression.png")
    path = ROOT / "config/final_reviews.json"
    reviews = read(path)
    check = {key: True for key,value in reviews[id].items() if isinstance(value,bool)}
    check.update(notes=notes, reviewer="Codex")
    reviews[id] = check
    meta.update(screen_facing=facing, visual_review="PASSED", acceptance=check)
    save(out / "animation.json", meta)
    save(path, reviews)
    cfg = ROOT / "config/cuts.json"
    cuts = read(cfg)
    cuts[id] = meta["cut"] | {"notes": notes}
    save(cfg, cuts)
    ref = folder / "first_frame.png"
    rel = lambda path: path.relative_to(ROOT).as_posix()
    manifest = ROOT / "output/generation_manifest.json"
    items = read(manifest) if manifest.exists() else {"items": {}}
    record = read(folder / "record.json")
    source_files = [folder / name for name in ("source.mp4", "record.json", "history.json", "prompt.txt", "repair.json") if (folder / name).exists()]
    items["items"][id] = {
        "model": "MiniMax H3 FL2VA pruned int8_convrot, ComfyUI 0.30.2",
        "workflow": rel(folder / "submitted_api.json"),
        "references": [{"path": rel(ref), "sha256": dig(ref)}],
        "seed": record["seed"], "attempts": record["attempt"],
        "source_files": list(map(rel, source_files)),
    }
    save(manifest, items)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="mode", required=True)
    cp = sub.add_parser("cut")
    cp.add_argument("id")
    cp.add_argument("attempt", type=int)
    cp.add_argument("start", type=int)
    cp.add_argument("end", type=int)
    cp.add_argument("events", type=int, nargs="+")
    pp = sub.add_parser("promote")
    pp.add_argument("id")
    pp.add_argument("attempt", type=int, help="0 for source-preserving repair")
    pp.add_argument("facing", choices=["left", "right", "front", "back"])
    pp.add_argument("notes")
    a = parser.parse_args()
    if a.mode == "cut":
        cut(a.id,a.attempt,a.start,a.end,a.events)
    else:
        promote(a.id,a.attempt,a.facing,a.notes)


if __name__ == "__main__":
    main()

