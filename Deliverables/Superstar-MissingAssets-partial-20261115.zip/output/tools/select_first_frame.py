"""Select a visually reviewed source frame for the next job."""
import argparse
import hashlib
import shutil
from pathlib import Path

import numpy as np
from PIL import Image

from comfy_jobs import ROOT, job_by_id, read, save
from extract_green_screen import remove_green


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("job_id")
    parser.add_argument("frame", type=int)
    parser.add_argument("--upstream")
    parser.add_argument("--attempt", type=int, default=1)
    parser.add_argument("--notes", required=True)
    args = parser.parse_args()
    job = job_by_id(args.job_id)
    run_root = ROOT / "runs" if args.upstream else ROOT / "runs" / "pose-prep"
    run = run_root / (args.upstream or args.job_id) / f"attempt_{args.attempt:02d}"
    source = run / "inspect" / f"source_{args.frame:06d}.png"
    capture = Image.open(source).convert("RGB")
    if capture.size != (640, 640):
        raise ValueError("Source frame has the wrong dimensions.")
    path = ROOT / job["first_frame"]
    if path.exists():
        raise FileExistsError(path)
    if args.upstream:
        # A chain reuses an exact source frame, including the pose and prop pixels.
        shutil.copyfile(source, path)
    else:
        # Generated preproduction frames may have nearly green compression artifacts.
        # Recompose only the original matte against the required pure green.
        fg = remove_green(np.asarray(capture), 24, 193, 0.55, 1)
        out = Image.new("RGB", capture.size, (0, 255, 0))
        out.paste(fg, mask=fg.getchannel("A"))
        out.save(path)
    review_path = ROOT / "config/first_frame_reviews.json"
    reviews = read(review_path)
    reviews[args.job_id].update(
        approved=True, identity_mapping_checked=True, action_ready=True, notes=args.notes,
        source=source.relative_to(ROOT).as_posix(), source_frame=args.frame,
        source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    )
    save(review_path, reviews)
    print(path)


if __name__ == "__main__":
    main()

