"""Draw the matching umbrella states and continuity-critical photo and label."""
import hashlib
from pathlib import Path

from PIL import Image, ImageDraw

from comfy_jobs import ROOT, save

OUT = ROOT / "runs" / "continuity-props"
OUT.mkdir(parents=True, exist_ok=True)
SCALE = 3


def canvas():
    return Image.new("RGBA", (512 * SCALE, 512 * SCALE))


def points(values):
    return [(round(x * SCALE), round(y * SCALE)) for x, y in values]


def poly(draw, vertices, fill, edge=None, width=2):
    coords = points(vertices)
    draw.polygon(coords, fill=fill)
    if edge:
        draw.line(coords + coords[:1], fill=edge, width=width * SCALE, joint="curve")


def line(draw, vertices, fill, width):
    draw.line(points(vertices), fill=fill, width=width * SCALE, joint="curve")


def box(coords):
    return tuple(round(x*SCALE) for x in coords)


def polish(image, key, anchors):
    image.resize((512, 512), Image.Resampling.LANCZOS).save(OUT / f"{key}.png")
    return anchors


def umbrella(opened):
    image = canvas()
    draw = ImageDraw.Draw(image)
    edge = "#302d37"
    line(draw, [(256, 105), (256, 393), (256, 415), (251, 428),
                (243, 435), (230, 435), (221, 427), (219, 415)], edge, 11)
    line(draw, [(254, 199), (254, 391)], "#5b5c63", 3)
    if opened:
        vertices = [(67, 231), (78,205), (96,182), (121,157), (153,137), (190,122),
                    (227,112), (256,108), (284,111), (321,120), (360,136), (392,157),
                    (418,182), (440,208), (445,231), (407,223), (365,227), (329,236),
                    (296,226), (256,230), (213,226), (180,235), (142,226), (103,222)]
        poly(draw, vertices, "#f3e0b6", "#716453", 3)
        poly(draw, [(256,110),(230,128),(200,158),(180,193),(180,233),
                    (211,225),(255,228)], "#fff0ce")
        poly(draw, [(257,110),(284,125),(317,155),(335,188),(328,234),
                    (367,225),(408,222),(441,229),(414,182),(360,137),
                    (322,122),(284,112)], "#e1c99e")
        for xs in [[(256,111),(224,137),(195,181),(180,233)],
                   [(256,111),(289,137),(315,179),(328,234)]]:
            line(draw, xs, "#a5947b", 2)
        tip = (256,108)
    else:
        poly(draw, [(256,108),(272,156),(279,224),(278,321),(263,353),
                    (247,352),(233,323),(233,231),(240,161)], "#f3e0b6", "#716453", 3)
        poly(draw, [(256,110),(266,165),(267,241),(263,348),(275,321),
                    (278,224),(271,156)], "#e1c99e")
        line(draw, [(254,128),(246,229),(247,331)], "#fff0ce", 4)
        draw.rounded_rectangle(box((231,293,279,307)), radius=3*SCALE, fill="#bea37e", outline="#897659", width=2*SCALE)
        tip = (256,108)
    draw.rounded_rectangle(box((253,99,259,114)), radius=2*SCALE, fill=edge)
    return polish(image, "P02_umbrella_open" if opened else "P01_umbrella_closed",
                  {"grip": [256, 390], "canopy_tip": list(tip)})


def label(draw, x, y, width, height):
    turn = round(height * .38)
    vertices = [(x,y),(x+width-turn,y),(x+width,y+turn),
                (x+width,y+height),(x,y+height)]
    poly(draw, vertices, "#daccaa", "#84765b", 2)
    poly(draw, [(x+width-turn,y),(x+width-turn,y+turn),(x+width,y+turn)],
         "#f5ead0", "#a89772", 1)


def photo():
    image = canvas()
    draw = ImageDraw.Draw(image)
    draw.rectangle(box((145, 86, 367, 423)), fill="#f4ebd4", outline="#777387", width=3*SCALE)
    draw.rectangle(box((158, 101, 354, 397)), fill="#9dabc7")
    ref = Image.open(ROOT / "references/baseline/S02_xiaobei_idle/first.png").convert("RGBA")
    alpha = ref.getchannel("A")
    ref = ref.crop(alpha.getbbox())
    height = 251 * SCALE
    ref = ref.resize((round(ref.width * height / ref.height), height), Image.Resampling.LANCZOS)
    image.alpha_composite(ref, ((512*SCALE-ref.width)//2, 137*SCALE))
    label(draw, 248, 92, 103, 38)
    photo_anchors = polish(image, "P07_photo_intact", {"grip": [151, 283], "label_attachment": [248, 92], "peel_corner": [351, 106]})
    image = canvas()
    label(ImageDraw.Draw(image), 100, 197, 309, 114)
    label_anchors = polish(image, "P08_old_label", {"grip": [408, 241], "attachment": [100, 197]})
    return photo_anchors, label_anchors


def main():
    p07, p08 = photo()
    save(OUT / "assets.json", {"P01_umbrella_closed": umbrella(False), "P02_umbrella_open": umbrella(True),
                              "P07_photo_intact": p07, "P08_old_label": p08})
    ref = ROOT / "references/baseline/S02_xiaobei_idle/first.png"
    save(OUT / "drawing_workflow.json", {"renderer": "Pillow ImageDraw at 3x with Lanczos",
         "script": "tools/draw_continuity_props.py", "photo_reference": ref.relative_to(ROOT).as_posix(),
         "photo_reference_sha256": hashlib.sha256(ref.read_bytes()).hexdigest(),
         "canvas": [512, 512], "color": "sRGB, straight alpha",
         "label_scale_relative_to_photo": 1 / 3})


if __name__ == "__main__":
    main()


