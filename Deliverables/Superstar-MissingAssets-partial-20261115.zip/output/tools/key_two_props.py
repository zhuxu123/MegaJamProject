"""Key the generated phone and rose while preserving the green leaf interiors."""
from PIL import Image
import cv2
import numpy as np

from comfy_jobs import ROOT, save
from draw_continuity_props import OUT

ids = ["P03_phone", "P05_white_rose"]
for key in ids:
    img = Image.open(ROOT / "runs/static" / key / "attempt_01/source.png").convert("RGB")
    rgb = np.asarray(img).astype(np.float64)
    green_bg = np.median(rgb[:, :20, :], axis=(0,1))
    dist = np.linalg.norm(rgb - green_bg, axis=2)
    strong = np.uint8(dist > 61 if key == "P05_white_rose" else dist > 91)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(strong)
    main = np.argmax(stats[1:,cv2.CC_STAT_AREA]) + 1
    solid = np.uint8(labels == main)
    if key == "P05_white_rose":
        contour, _ = cv2.findContours(solid, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(solid, contour, -1, 1, cv2.FILLED)
    rgba = img.convert("RGBA")
    rgba.putalpha(Image.fromarray(solid * 255))
    rgba.save(OUT / f"{key}.png")
save(OUT / "keyed_assets.json", {
    "P03_phone": {"grip": [178,341],"screen_center":[256,249]},
    "P05_white_rose": {"grip": [247,385],"flower_center":[263,143]},
})

