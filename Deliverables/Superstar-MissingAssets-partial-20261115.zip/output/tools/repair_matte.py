"""Repair the baseline mattes without modifying the source videos."""
import argparse
import shutil
from pathlib import Path
from types import SimpleNamespace

import cv2
import numpy as np
from PIL import Image

from comfy_jobs import ROOT, job_by_id, read, save
import export_animation
from export_with_av import decode, probe


def edge_matte(rgb, foreground, background, feather, despill):
    red, green, blue = np.moveaxis(rgb.astype(np.float32), -1, 0)
    excess = np.maximum(green - np.maximum(red, blue), 0)
    screen = np.median(np.concatenate((excess[:16, :].ravel(), excess[:, :16].ravel(),
                                       excess[:, -16:].ravel())))
    if screen < 110:
        raise ValueError("Source background is not the expected saturated green.")
    alpha = np.clip((screen * 0.85 - excess) / (screen * 0.76), 0, 1)
    alpha = alpha**2 * (3 - 2 * alpha)
    _, labels = cv2.distanceTransformWithLabels(
        np.uint8(alpha < 0.985), cv2.DIST_L2, 5, labelType=cv2.DIST_LABEL_PIXEL)
    core = labels[alpha >= 0.985]
    if not core.size:
        raise ValueError("No opaque foreground.")
    pixels = rgb.copy()
    pixels[:, :, 1] = np.minimum(green, np.maximum(red, blue))
    colors = np.zeros((labels.max() + 1, 3), dtype=np.float32)
    colors[core] = pixels[alpha >= 0.985]
    mix = np.clip((0.98 - alpha) / 0.48, 0, 1)[..., None]
    mix = np.maximum(mix, np.clip((excess / screen - 0.08) * 0.8, 0, 0.35)[..., None])
    visible = (pixels * (1 - mix) + colors[labels] * mix).round().astype(np.uint8)
    visible[alpha == 0] = 0
    return Image.fromarray(np.dstack([visible, np.rint(255 * alpha).astype(np.uint8)]))


def repair(key, offset=0):
    job = job_by_id(key)
    baseline = ROOT / "baseline/original_delivery/final" / key
    old = read(baseline / "animation.json")
    run = ROOT / "runs" / key / "baseline_repair"
    run.mkdir(parents=True, exist_ok=True)
    for name in ("source.mp4", "first_frame.png", "submitted_api.json", "prompt.txt", "record.json", "history.json"):
        if not (run / name).exists():
            shutil.copy2(baseline / name, run / name)
    src = run / "source.mp4"
    cut = dict(old["cut"], video=src.relative_to(ROOT).as_posix())
    export_animation.probe = probe
    cursor = 0
    def source_frames(path):
        nonlocal cursor
        for cursor, rgb in enumerate(decode(path),1):
            yield rgb
    export_animation.decode = source_frames
    selected = None
    if key.startswith("C07"):
        # Shorten only the long suspended plateau. Preserve onset, strike and recovery.
        indices = [20, 25, 30, 37, 59, 68, 73, 78, 82, 87, 92, 97]
        timestamps = probe(src)["times"]
        selected = [i - 1 for i in indices]
        export_animation.select_samples = lambda meta, cut: (selected, [timestamps[i] for i in selected])
    def matte(*args):
        result = edge_matte(*args)
        y = offset
        if key.startswith("C05"):
            # Keep the exact C04 kneeling match. Align only as the support foot raises the body.
            weight = min(1., max(0., (cursor - 48) / 22))
            y = round(offset * weight * weight * (3 - 2 * weight))
        if y:
            shifted = Image.new("RGBA", result.size)
            shifted.paste(result, (0, y))
            return shifted
        return result
    export_animation.remove_green = matte
    out = ROOT / "runs" / "repair-candidates" / key
    meta = export_animation.export(job, cut, out, SimpleNamespace(
        foreground=24, background=193, feather=0, despill=1))
    meta.update(screen_facing="left" if key.startswith("C09") else "right",
                processing={"matte": "screen-adaptive chroma / nearest opaque RGB decontamination",
                            "standing_offset_y": offset,
                            "offset_ramp_source_frames": [48,70] if key.startswith("C05") else None,
                            "retime": "compressed midair hold, original frame indices retained" if selected else None},
                visual_review="REQUIRED_NOT_AUTOMATICALLY_PASSED")
    save(out / "animation.json", meta)
    save(run / "repair.json", meta["processing"])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("id")
    parser.add_argument("--offset", type=int, default=0)
    args = parser.parse_args()
    repair(args.id, args.offset)


