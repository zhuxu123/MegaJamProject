"""Reuse a registered master only after the matching start pose has been checked."""
import argparse
import hashlib
from pathlib import Path
import shutil

from PIL import Image, ImageOps

from comfy_jobs import ROOT, job_by_id, read, save

p=argparse.ArgumentParser()
p.add_argument("id")
p.add_argument("--flip",action="store_true")
p.add_argument("--notes",required=True)
args=p.parse_args()
job=job_by_id(args.id)
src=ROOT / "runs/identity-prep" / f"{job['character']}-identity.png"
dst=ROOT / job["first_frame"]
if dst.exists():
    raise FileExistsError(dst)
if args.flip:
    ImageOps.mirror(Image.open(src)).save(dst)
else:
    shutil.copyfile(src,dst)
review_path=ROOT / "config/first_frame_reviews.json"
data=read(review_path)
data[args.id].update(approved=True,identity_mapping_checked=True,action_ready=True,
                     notes=args.notes,source=src.relative_to(ROOT).as_posix(),
                     source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),flipped=args.flip)
save(review_path,data)

