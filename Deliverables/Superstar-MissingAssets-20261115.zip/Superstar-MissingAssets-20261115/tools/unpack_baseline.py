"""Extract included baseline archives without overwriting existing work."""
from pathlib import Path
import zipfile
ROOT=Path(__file__).resolve().parents[1]
for name in ['original_delivery','acceptance']:
    target=ROOT/'baseline'/name
    if target.exists():
        print(f'SKIP existing {target}; inspect it instead of overwriting.')
        continue
    with zipfile.ZipFile(ROOT/'baseline'/f'{name}.zip') as archive:
        for item in archive.infolist():
            resolved=(target/item.filename.replace('\\','/')).resolve()
            if not resolved.is_relative_to(target.resolve()): raise ValueError(f'Unsafe archive entry: {item.filename}')
            if (item.external_attr >> 16) & 0o170000 == 0o120000: raise ValueError('Symlink entry rejected')
        archive.extractall(target)
    print(f'EXTRACTED {name}')
