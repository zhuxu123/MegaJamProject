"""Validate real incremental delivery. Visual-only mode explicitly excludes audio."""
from pathlib import Path
import argparse,json,hashlib,wave
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(__doc__);p.add_argument('--visual-only',action='store_true');p.add_argument('--output',type=Path,default=ROOT/'output');args=p.parse_args();out=args.output.resolve()
errors=[]
def read(path):
    try:return json.loads(path.read_text(encoding='utf-8-sig'))
    except Exception as e:errors.append(f'{path}: {e}');return {}
def need(value,msg):
    if not value:errors.append(msg)
def file(rel):
    q=(out/rel).resolve()
    if not q.is_relative_to(out):errors.append(f'Unsafe output path {rel}');return out/'__REJECTED_PATH__'
    need(q.is_file(),f'Missing {rel}');return q
def review(records,id,fields):
    r=records.get(id,{})
    need(all(r.get(k) is True for k in fields),f'{id}: incomplete actual review {fields}')
    need(bool(r.get('notes')),f'{id}: review notes missing')
jobs=read(ROOT/'config/jobs.json');static=read(ROOT/'config/static_jobs.json');audios=read(ROOT/'config/audio_jobs.json')
reviews=read(out/'reviews.json');sreviews=read(out/'static_reviews.json');reuse=read(out/'reuse_reviews.json')
for j in jobs:
    id=j['id'];base=out/'animations'/id;meta=read(base/'animation.json')
    if not meta:continue
    need(meta.get('id')==id and meta.get('fps')==5 and meta.get('loop') is j['loop'],f'{id}: ID/fps/loop mismatch')
    need(meta.get('canvas')==[640,640] and meta.get('anchor_pixels')==[320,570],f'{id}: canvas/anchor mismatch')
    frames=sorted((base/'frames').glob('*.png'));need(len(frames)==meta.get('frame_count') and len(frames)>0,f'{id}: frame count')
    need(len(meta.get('frame_mapping',[]))==len(frames),f'{id}: missing source mapping')
    mapping=meta.get('frame_mapping',[])
    need(all(abs(m.get('output_seconds',-100)-i/5)<1e-6 for i,m in enumerate(mapping)),f'{id}: output timeline is not 5 fps')
    source_indices=[m.get('source_frame') for m in mapping]
    need(len(set(source_indices))==len(source_indices),f'{id}: duplicated source frames')
    for i,frame in enumerate(frames,1):
        need(frame.name==f'{id}_{i:06d}.png',f'{id}: sequence filename {frame.name}')
        try:
            with Image.open(frame) as im:
                need(im.mode=='RGBA' and im.size==(640,640),f'{frame}: RGBA/size')
                need(im.getchannel('A').getextrema()[0]==0 and im.getchannel('A').getbbox() is not None,f'{frame}: missing transparency/foreground')
        except Exception as e:errors.append(str(e))
    need(set(j['events'])<=set(meta.get('events',{})),f'{id}: required events missing')
    source=file(meta.get('source','MISSING_SOURCE'))
    if source.is_file():need(hashlib.sha256(source.read_bytes()).hexdigest()==meta.get('source_sha256'),f'{id}: source hash mismatch')
    if j['kind']=='expression':
        expr=file(f'animations/{id}/expression.png')
        if expr.is_file():need(any(expr.read_bytes()==f.read_bytes() for f in frames),f'{id}: expression.png is not a delivered frame')
    review(reviews,id,['approved','no_intro','events_readable_5fps','alpha_on_light_dark','identity_and_props','anchor_and_bounds','loop_or_chain_checked','facial_acting_checked'])
for j in static:
    q=file(Path(j['output']).relative_to('output'))
    if q.is_file():
        try:
            with Image.open(q) as im:
                need(list(im.size)==j['canvas'],f'{j["id"]}: static dimensions')
                if j['alpha']:need(im.mode=='RGBA' and im.getchannel('A').getextrema()[0]==0,f'{j["id"]}: alpha missing')
        except Exception as e:errors.append(str(e))
    review(sreviews,j['id'],['approved','identity_and_style','alpha_or_background','content_matches_script'])
for id in read(ROOT/'config/reuse_existing.json')['reuse_not_regenerate']:review(reuse,id,['approved'])
for group in read(ROOT/'integration/sync_groups.json'):
    id=group['id'];base=out/'sync'/id;r=read(base/'review.json')
    review({id:r},id,['approved','contact_checked','prop_count_checked','timing_checked'])
    interaction=read(base/'interaction.json');need(interaction.get('shared_event')==group['event'],f'{id}: shared event missing')
    need((base/'preview_5fps.gif').is_file() or (base/'preview_5fps.mp4').is_file(),f'{id}: composite preview missing')
    for clip in group['clips']:
        m=read(out/'animations'/clip/'animation.json')
        need(group['event'] in m.get('events',{}),f'{id}/{clip}: measured shared event missing')
if not args.visual_only:
    areviews=read(out/'audio_reviews.json')
    for j in audios:
        q=file(Path(j['output']).relative_to('output'))
        if q.is_file():
            try:
                with wave.open(str(q),'rb') as w:need(w.getframerate()==48000 and w.getsampwidth()==3 and w.getnframes()>0,f'{j["id"]}: WAV format')
            except Exception as e:errors.append(str(e))
        review(areviews,j['id'],['approved','auditioned'])
file('DELIVERY.md');generation=read(out/'generation_manifest.json')
need(isinstance(generation.get('items'),dict),'generation_manifest.json requires items keyed by task ID')
for j in jobs+static+([] if args.visual_only else audios):
    record=generation.get('items',{}).get(j['id'],{})
    need(bool(record.get('model')) and bool(record.get('workflow')) and bool(record.get('references')),f'{j["id"]}: missing real generation provenance')
    if record.get('workflow'):file(record['workflow'])
    for ref in record.get('references',[]):
        if not isinstance(ref,dict):errors.append(f'{j["id"]}: references require path/sha256 objects');continue
        q=file(ref.get('path','MISSING_REFERENCE'))
        if q.is_file():need(hashlib.sha256(q.read_bytes()).hexdigest()==ref.get('sha256'),f'{j["id"]}: reference hash mismatch')
manifest=read(out/'MANIFEST.sha256.json')
for rel,sha in manifest.items():
    q=file(rel)
    if q.is_file():need(hashlib.sha256(q.read_bytes()).hexdigest()==sha,f'Hash mismatch {rel}')
actual={q.relative_to(out).as_posix() for q in out.rglob('*') if q.is_file() and q.name!='MANIFEST.sha256.json'}
need(actual==set(manifest),'Manifest does not cover all actual files')
if errors:
    print('\n'.join(errors[:100]));print(f'FAIL: {len(errors)} missing/invalid checks. No incomplete delivery is approved.');raise SystemExit(1)
print('VISUAL PASS (audio and unspecified long dialogue excluded)' if args.visual_only else 'DELIVERY PASS (unspecified long dialogue remains explicitly deferred)')
