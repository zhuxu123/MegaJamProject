"""Offline structural checks for the instructions package, not generated art approval."""
from pathlib import Path
import json,hashlib,ast
ROOT=Path(__file__).resolve().parents[1]
def read(p): return json.loads((ROOT/p).read_text(encoding='utf-8-sig'))
jobs=read('config/jobs.json');static=read('config/static_jobs.json');audio=read('config/audio_jobs.json')
chars={c['id']:c for c in read('config/characters.json')}
alljobs={j['id']:j for j in jobs+static+audio}
assert len(alljobs)==len(jobs)+len(static)+len(audio),'Duplicate IDs'
assert 'limou' in chars and 'director' not in chars
assert read('config/scope.json')['director_is_limou'] is True
assert read('integration/reuse_scenes.json')['generate_new_scenes'] is False
for p in (ROOT/'tools').glob('*.py'): ast.parse(p.read_text(encoding='utf-8-sig'),filename=str(p))
for j in jobs:
    assert j['character'] in chars and j['export_fps']==5 and j['canvas']==[640,640] and j['anchor']==[320,570]
    assert (ROOT/j['prompt']).is_file() and (ROOT/j['first_frame_prompt']).is_file()
    assert (ROOT/f'tasks/{j["id"]}.md').is_file()
    for dep in j.get('dependencies',[]): assert dep.startswith('baseline:') or dep in alljobs,(j['id'],dep)
    prompt=(ROOT/j['prompt']).read_text(encoding='utf-8')
    assert prompt.startswith('For the target video, at 0.00 seconds')
    assert prompt.index('integrated_multimodal_description:')<prompt.index('overall_soundscape:')<prompt.index('non_diegetic_music:')
for j in static:
    assert (ROOT/j['prompt']).is_file()
    for ref in j['references']: assert ref.startswith('output/') or (ROOT/ref).is_file(),ref
seen=set();visiting=set()
def visit(id):
    if id in seen:return
    assert id not in visiting, f'Cyclic dependency {id}'
    visiting.add(id)
    for dep in alljobs[id].get('dependencies',[]):
        if not dep.startswith('baseline:'):visit(dep)
    visiting.remove(id);seen.add(id)
for j in jobs:visit(j['id'])
maps=read('integration/beat_assets.json');assert len(maps)==39
for b in maps:
    for id in b['animation_ids']+b['static_ids']:assert id in alljobs
for g in read('integration/sync_groups.json'):
    for id in g['clips']:assert id in alljobs
for p in ['baseline/original_delivery.zip','baseline/acceptance.zip','sources/剧本全.docx','START_HERE.md','交给生成Agent.txt']:
    assert (ROOT/p).is_file(),p
manifest=ROOT/'MANIFEST.sha256.json'
if manifest.exists():
    for p,h in read('MANIFEST.sha256.json').items(): assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,p
print(f'HANDOFF PASS: {len(jobs)} animation tasks, {len(static)} static tasks, {len(audio)} audio tasks, 39 beat mappings; dependency DAG, prompts and packaged references valid. No artwork has been generated or approved by this check.')
