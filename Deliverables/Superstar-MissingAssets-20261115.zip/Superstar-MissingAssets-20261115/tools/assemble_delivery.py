"""Collect source evidence and snapshots; never creates approvals or missing art."""
from pathlib import Path
import hashlib,json,shutil
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def cp(src,dst):
    if not src.is_file():raise FileNotFoundError(src)
    if dst.exists():
        if src.read_bytes()!=dst.read_bytes():raise FileExistsError(f'Different existing file: {dst}; preserve and reconcile it explicitly.')
        return
    dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
if not OUT.is_dir():raise SystemExit('Generate output assets first.')
for task in read(ROOT/'config/jobs.json'):
    folder=OUT/'animations'/task['id'];meta=folder/'animation.json'
    if not meta.is_file():continue
    data=read(meta);rel=Path(data['source'])
    source=(ROOT/rel).resolve()
    if rel.is_absolute() or not source.is_relative_to(ROOT):raise ValueError('Source must be package-relative')
    cp(source,OUT/rel)
    for name in ['first_frame.png','submitted_api.json','prompt.txt','record.json']:
        cp(source.parent/name,OUT/rel.parent/name)
    cp(ROOT/task['prompt'],OUT/'prompts'/Path(task['prompt']).name)
cp(ROOT/'config/final_reviews.json',OUT/'reviews.json')
for directory in ['config','integration']:
    for p in (ROOT/directory).glob('*.json'):cp(p,OUT/'handoff_snapshot'/directory/p.name)
for p in (ROOT/'references').rglob('*'):
    if p.is_file():cp(p,OUT/p.relative_to(ROOT))
generation=OUT/'generation_manifest.json'
if generation.is_file():
    data=read(generation)
    def collect(rel):
        rel=Path(rel)
        if rel.parts and rel.parts[0]=='output':rel=Path(*rel.parts[1:])
        if rel.is_absolute() or '..' in rel.parts:raise ValueError(f'Unsafe provenance path: {rel}')
        src=ROOT/rel
        if not src.is_file():src=OUT/rel
        cp(src,OUT/rel)
        return rel.as_posix()
    for item in data.get('items',{}).values():
        item['workflow']=collect(item['workflow'])
        for ref in item.get('references',[]):
            ref['path']=collect(ref['path'])
            actual=hashlib.sha256((OUT/ref['path']).read_bytes()).hexdigest()
            if ref.get('sha256')!=actual:raise ValueError(f'Reference hash mismatch: {ref["path"]}')
        item['source_files']=[collect(r) for r in item.get('source_files',[])]
    generation.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
manifest={p.relative_to(OUT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='MANIFEST.sha256.json'}
(OUT/'MANIFEST.sha256.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(f'Collected provenance and hashed {len(manifest)} files. Run validate_delivery; this is not approval.')
