# ComfyUI 环境与工作流

本包已经带有完整 API 工作流。接手电脑只需可运行兼容 H3 的 ComfyUI，无须提前保存同名画布工作流。API JSON 是 `/prompt` 的数据，不能保证直接拖入所有版本的前端都能还原画布。

## 基线和文件

- 用户提供原 API：`workflows/h3_i2v_original_api.json`。
- 本次执行 API：`workflows/h3_i2v_640_api.json`。将分辨率选择、数学表达式、时长常量三个辅助节点折叠为 width=640、height=640、length=124，其余采样链保持原样。
- 本机只读核对的参考代码：ComfyUI 0.30.2，commit `dec5d9450a5290bcf63430409ea41018e67f41c3`，该 checkout 无未提交修改。它是复现参照，不是对另一台机器的兼容承诺。
- `MiniMaxH3ImageToVideo` 在 `comfy_extras/nodes_minimax_h3.py`；原图的 `ResolutionSelector` 与 `ComfyMathExpression` 也来自此版本核心。不要按猜测安装同名第三方包。
- H3 提示词格式来自提供的 H3 技能，片段本身已完整写入包内，不需要安装该技能。

## 模型清单

| 角色 | 文件 | ComfyUI models 下目录 |
| --- | --- | --- |
| 视频扩散 | minimax_h3_fl2va_pruned_int8_convrot.safetensors | diffusion_models |
| 文本编码器 | qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors | text_encoders |
| 视频 VAE | minimax_h3_video_vae_fp16.safetensors | vae |
| 音频 VAE | minimax_h3_audio_vae_fp32.safetensors | vae |

模型来自 [Comfy-Org MiniMax H3 模型库](https://huggingface.co/Comfy-Org/MiniMax-H3/tree/main)。同库的目录结构与上表对应。官方模型卡说明 int8_convrot 优先配合支持的 PyTorch cu130 环境，nvfp4 编码器不限定 Blackwell；实际兼容性仍以单条试跑为准。[模型卡](https://huggingface.co/Comfy-Org/MiniMax-H3)

不要一次性盲下整仓库。先复用本机已有的四个文件或外部模型目录。需要下载时可在所选 Python 环境安装 huggingface_hub，再按表逐个执行如下命令；实际模型下载需网络及足够磁盘空间。不要把 CPU RAM、显存或磁盘最低值猜成保证条件。

```powershell
python -m pip install huggingface_hub
hf download Comfy-Org/MiniMax-H3 diffusion_models/minimax_h3_fl2va_pruned_int8_convrot.safetensors --local-dir '<ComfyUI根目录>/models'
hf download Comfy-Org/MiniMax-H3 text_encoders/qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors --local-dir '<ComfyUI根目录>/models'
hf download Comfy-Org/MiniMax-H3 vae/minimax_h3_video_vae_fp16.safetensors --local-dir '<ComfyUI根目录>/models'
hf download Comfy-Org/MiniMax-H3 vae/minimax_h3_audio_vae_fp32.safetensors --local-dir '<ComfyUI根目录>/models'
```

上述来源于官方仓库布局；Hugging Face CLI 在执行机用 `hf download --help` 核对可用性。下载后记录具体 revision、大小和 SHA256。遇同名不同版本，不覆盖已有文件，使用独立模型目录并记录映射。

## 启动与预检

沿用本机正常启动 ComfyUI 的方式，默认接口 `http://127.0.0.1:8188`；端口不同就传 `--url`。无需开放公网。先在当前包目录运行：

```powershell
python --version
ffmpeg -version
ffprobe -version
python -m pip install -r requirements.txt
python tools/comfy_jobs.py verify-package
python tools/comfy_jobs.py preflight --url http://127.0.0.1:8188
```

`preflight` 检查 `/system_stats`、所有执行图节点及四个模型名，输出 `runs/preflight.json`。出现缺节点先查看 ComfyUI 启动报错和版本；完整核心更新应按本机安装类型进行，不把单个核心 py 文件散拷到旧版。保留原安装及自定义节点配置，必要时建旁路环境。[官方更新说明](https://docs.comfy.org/installation/update_comfyui)

缺模型时核对 models 路径、extra_model_paths 配置、文件名及加载器返回列表。若模型在子目录中，编辑执行图加载器字段为列表返回的完整相对名，并记录变更。OOM 或算子不兼容先检查显存占用及官方支持的精度方案；确需换精度模型，留存新图与环境记录，重跑代表动作。不能通过只改后缀伪装不同权重。

## 固定运行参数

640×640、24 FPS、124 源帧、约 5.167 秒，采样器 res_multistep、simple 调度器、20 steps、denoise=1，音视频都保留解码节点。提示词按 5 秒动作设计，超过 5 秒的编码余量不强行纳入有效动画。**5 FPS 是最终 PNG 播放与采样频率，不改 H3 时间基准。**

若希望用前端查看，可从 [官方 I2V 画布模板](https://github.com/Comfy-Org/workflow_templates/blob/main/templates/video_minimax_h3_i2v.json) 获取相同模型家族的参考画布；它可能随上游变化，正式运行仍使用包内快照。API 提交无需该外部下载。

## 首帧制作能力

包内附带原图和逐条首帧提示词，不包含未经验证的图像模型工作流。接手 Agent 使用已有的参考图编辑工具或 ComfyUI 中可用的参考图编辑模型制作单人物动作准备图。仅换背景可用选区抠图合成；涉及换姿态、加纸张或修改持物关系，必须有图像编辑能力，不能用普通裁剪假装完成。若机器只有 H3，可用原图中对应单人物全身裁出身份基图，先生成姿态候选再取干净帧作正式 I2V 输入；这轮是首帧预制作，不能交作最终动作。若仍无法得到合格首帧，记录具体失败条目，不将其他人物或多格图带入正式批量。
