# A08_xiaozhou_jog — 助理小跑

优先级：P1；类型：action；人物：助理小周；循环：True。

复用剧情段落：[4]。依赖：['REF_xiaozhou']。

动作：Jog in place holding a closed cream umbrella in the right hand; keep the umbrella rigid and intact.

表情：attentive urgency

首帧提示词：`prompts/first_frame/A08_xiaozhou_jog.txt`；视频提示词：`prompts/video/A08_xiaozhou_jog.txt`。

必须实测的事件：cycle_start, opposite_phase, cycle_return。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A08_xiaozhou_jog/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
