# R01_linwan_peel_label — 扯下旧标签（替代撕整张照片）

优先级：P0；类型：story_replacement；人物：林晚；循环：False。

复用剧情段落：[8]。依赖：先锁定角色母版。

动作：At frame zero the hand is already near eye level at the raised corner of a small old label on ONE intact contestant photo. Pinch only the peeling label, pull it off in one clear short motion and hold the removed strip. The photo remains whole. No tearing the photo into two pieces.

表情：concentrated disapproval, intent readable but whether helping or sabotaging remains ambiguous

首帧提示词：`prompts/first_frame/R01_linwan_peel_label.txt`；视频提示词：`prompts/video/R01_linwan_peel_label.txt`。

必须实测的事件：pinch_label, label_removed, photo_intact_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/R01_linwan_peel_label/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
