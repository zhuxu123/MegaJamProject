# A17_xiaobei_crouch_empty — 再蹲下准备收拾

优先级：P1；类型：action；人物：小北；循环：False。

复用剧情段落：[11, 12]。依赖：['A16_xiaobei_rise_empty']。

动作：From A16 standing endpoint, bend the knees and crouch toward the same three scattered sheets; stop at the ready-to-collect pose matching C04.

表情：urgent lowered gaze

首帧提示词：`prompts/first_frame/A17_xiaobei_crouch_empty.txt`；视频提示词：`prompts/video/A17_xiaobei_crouch_empty.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A17_xiaobei_crouch_empty/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
