# A27_linwan_mirror_idle — 镜前坐姿

优先级：P1；类型：action；人物：林晚；循环：True。

复用剧情段落：[24, 25, 27]。依赖：先锁定角色母版。

动作：Sit on an invisible fixed-height stool facing three-quarter away toward screen right; breathe subtly with feet at the established floor line. No stool or mirror baked into the sprite.

表情：quiet guarded face, eyes directed toward an offscreen mirror

首帧提示词：`prompts/first_frame/A27_linwan_mirror_idle.txt`；视频提示词：`prompts/video/A27_linwan_mirror_idle.txt`。

必须实测的事件：cycle_start, opposite_phase, cycle_return。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A27_linwan_mirror_idle/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
