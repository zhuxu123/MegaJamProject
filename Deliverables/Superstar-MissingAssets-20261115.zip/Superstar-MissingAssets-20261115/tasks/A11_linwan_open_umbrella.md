# A11_linwan_open_umbrella — 撑开雨伞

优先级：P1；类型：action；人物：林晚；循环：False。

复用剧情段落：[5]。依赖：['A09_linwan_take_umbrella']。

动作：Starting with the closed cream umbrella in hand, raise it beside the shoulder and open it once above the head. Keep the entire canopy inside the frame.

表情：neutral detached expression

首帧提示词：`prompts/first_frame/A11_linwan_open_umbrella.txt`；视频提示词：`prompts/video/A11_linwan_open_umbrella.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A11_linwan_open_umbrella/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
