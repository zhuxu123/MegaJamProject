# A41_linwan_knife_advance — 握刀压低重心

优先级：P1；类型：action；人物：林晚；循环：False。

复用剧情段落：[29]。依赖：['A40_linwan_receive_knife']。

动作：Start holding the prop knife at waist height, tighten the grip, lower the center of mass and move forward half a small step. Never make contact with another person.

表情：alert focused eyes and firm mouth

首帧提示词：`prompts/first_frame/A41_linwan_knife_advance.txt`；视频提示词：`prompts/video/A41_linwan_knife_advance.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A41_linwan_knife_advance/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
