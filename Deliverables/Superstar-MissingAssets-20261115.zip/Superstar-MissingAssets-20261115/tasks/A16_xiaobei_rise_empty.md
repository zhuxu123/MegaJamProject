# A16_xiaobei_rise_empty — 扶膝空手起身

优先级：P1；类型：action；人物：小北；循环：False。

复用剧情段落：[11]。依赖：['baseline:C03_xiaobei_fall_scatter']。

动作：From the exact fallen endpoint of C03 with the three papers remaining on the ground, push up using both knees and stand without collecting any paper.

表情：distressed lowered gaze; never cheerful

首帧提示词：`prompts/first_frame/A16_xiaobei_rise_empty.txt`；视频提示词：`prompts/video/A16_xiaobei_rise_empty.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A16_xiaobei_rise_empty/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
