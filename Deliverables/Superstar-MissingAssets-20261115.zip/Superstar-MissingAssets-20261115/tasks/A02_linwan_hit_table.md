# A02_linwan_hit_table — 愤怒敲桌

优先级：P1；类型：action；人物：林晚；循环：False。

复用剧情段落：[2]。依赖：先锁定角色母版。

动作：Raise the right hand briefly and strike down once to a fixed invisible tabletop contact point at waist height; settle without repeating. No furniture is baked into the sprite.

表情：brows drawn together, narrowed eyes and tightly pressed lips; anger is visible before contact

首帧提示词：`prompts/first_frame/A02_linwan_hit_table.txt`；视频提示词：`prompts/video/A02_linwan_hit_table.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A02_linwan_hit_table/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
