# E04_extra_m_walk — 原地走路循环 / 两侧着地基线

优先级：P0；类型：repair；人物：路人男；循环：True。

复用剧情段落：[7]。依赖：先锁定角色母版。

动作：Begin a steady in-place walk at 0.00 seconds. Alternate clear left and right foot contacts at a relaxed pace, with modest hip motion and natural arm movement allowed by held props. Keep a stationary screen-space root and constant screen-right facing direction. For the woman, the left hand keeps the clipboard and the right hand keeps the pen throughout; no swapping or new props. Complete repeated left-plus-right gait cycles, returning to the same foot phase and motion direction each cycle. Do not turn, stop, walk out of frame, or invent facial features. Correct both ground-contact phases to the E03 standing floor line; preserve flight and body bob, never snap each frame by bounding box.

表情：keep the intentionally featureless face

首帧提示词：`prompts/first_frame/E04_extra_m_walk.txt`；视频提示词：`prompts/video/E04_extra_m_walk.txt`。

必须实测的事件：左脚着地, 右脚着地, 完整左右步周期, 道具与无五官特征保持。事件时间不得从提示词抄成测量结果。

交付 `output/animations/E04_extra_m_walk/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
