# C05_xiaobei_rise_papers — 抱资料从跪姿起立 / 基线偏低

优先级：P0；类型：repair；人物：小北；循环：False。

复用剧情段落：[13]。依赖：['baseline:C04_xiaobei_collect_papers']。

动作：Begin rising immediately at 0.00 seconds. From 0.00–1.20 seconds plant one foot while maintaining the paper grip. From 1.20–2.80 seconds shift weight and push up smoothly. From 2.80–3.80 seconds straighten both legs, returning to a balanced standing pose. Keep the stack held against her chest without changing its count or size. From 3.80 seconds onward hold that standing pose with very subtle breathing. Do not drop paper, run, or kneel again. Keep the planted-foot baseline registered to S02; correct the persistent 5–6 pixel endpoint offset without per-frame bbox snapping.

表情：tense distressed eyes, no cheerful smile

首帧提示词：`prompts/first_frame/C05_xiaobei_rise_papers.txt`；视频提示词：`prompts/video/C05_xiaobei_rise_papers.txt`。

必须实测的事件：单脚支撑, 身体上升, 双腿站直, 持资料站稳。事件时间不得从提示词抄成测量结果。

交付 `output/animations/C05_xiaobei_rise_papers/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
