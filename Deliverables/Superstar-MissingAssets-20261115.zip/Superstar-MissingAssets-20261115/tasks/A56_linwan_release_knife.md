# A56_linwan_release_knife — 交出道具刀

优先级：P1；类型：action；人物：林晚；循环：False。

复用剧情段落：[31]。依赖：先锁定角色母版。

动作：Lower the held prop knife, allow an offscreen staff member to grasp the handle, release it once and end with empty hands ready for A44.

表情：shocked restrained protest conveyed without invented speech

首帧提示词：`prompts/first_frame/A56_linwan_release_knife.txt`；视频提示词：`prompts/video/A56_linwan_release_knife.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A56_linwan_release_knife/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
