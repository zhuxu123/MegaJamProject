# A28_chenmo_walk — 陈默走路

优先级：P1；类型：action；人物：陈默；循环：True。

复用剧情段落：[24, 26, 32, 34]。依赖：['REF_chenmo']。

动作：Walk in place with a slow measured gait, hands relaxed, fixed root.

表情：calm supportive expression

首帧提示词：`prompts/first_frame/A28_chenmo_walk.txt`；视频提示词：`prompts/video/A28_chenmo_walk.txt`。

必须实测的事件：cycle_start, opposite_phase, cycle_return。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A28_chenmo_walk/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
