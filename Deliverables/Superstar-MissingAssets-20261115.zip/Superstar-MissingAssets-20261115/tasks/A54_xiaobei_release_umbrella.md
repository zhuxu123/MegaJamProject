# A54_xiaobei_release_umbrella — 林晚抢伞后松手

优先级：P1；类型：action；人物：小北；循环：False。

复用剧情段落：[39]。依赖：['A53_xiaobei_walk_umbrella']。

动作：Hold the closed cream umbrella at the shared transfer point, release it as the offscreen partner takes it and retract the now empty hand.

表情：brief surprise followed by a quiet neutral look, no invented ending reaction

首帧提示词：`prompts/first_frame/A54_xiaobei_release_umbrella.txt`；视频提示词：`prompts/video/A54_xiaobei_release_umbrella.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A54_xiaobei_release_umbrella/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
