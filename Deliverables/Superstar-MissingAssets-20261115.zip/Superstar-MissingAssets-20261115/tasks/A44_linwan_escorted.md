# A44_linwan_escorted — 被带离舞台

优先级：P1；类型：action；人物：林晚；循环：True。

复用剧情段落：[31]。依赖：['A56_linwan_release_knife']。

动作：Walk in place toward screen left with upper arms slightly constrained at two fixed offscreen grip points; hands empty after a separately recorded prop-knife handoff.

表情：shocked and unwilling but composed; no falling or injuries

首帧提示词：`prompts/first_frame/A44_linwan_escorted.txt`；视频提示词：`prompts/video/A44_linwan_escorted.txt`。

必须实测的事件：cycle_start, opposite_phase, cycle_return。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A44_linwan_escorted/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
