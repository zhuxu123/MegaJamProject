# A09_linwan_take_umbrella — 抢过雨伞

优先级：P1；类型：action；人物：林晚；循环：False。

复用剧情段落：[4, 39]。依赖：先锁定角色母版。

动作：Reach toward an offscreen partner, grip the curved handle of the closed cream umbrella at the agreed transfer point and pull it back to the torso once.

表情：impatient controlled glance; no extra hand or duplicate umbrella

首帧提示词：`prompts/first_frame/A09_linwan_take_umbrella.txt`；视频提示词：`prompts/video/A09_linwan_take_umbrella.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A09_linwan_take_umbrella/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
