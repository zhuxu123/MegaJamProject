# C06_linwan_push_palm — 伸手掌向前推 / 手臂黄绿污染

优先级：P0；类型：repair；人物：林晚；循环：False。

复用剧情段落：[10]。依赖：先锁定角色母版。

动作：Immediately extend the right arm forward from 0.00–1.20 seconds, with the open palm pushing toward screen right. From 1.20–2.00 seconds keep the palm clearly extended and upright, fingers together, elbow not hyperextended. From 2.00–3.60 seconds retract smoothly. From 3.60 seconds onward settle into the initial ready stance. This is an open-palm forward push gesture, not a punch, wave, grab, or actual catch. No second person appears and no paper materializes in her hand. Remove green/yellow edge contamination on fingers and forearm without eroding the hand silhouette. Prefer rematting the existing source.

表情：controlled guarded coldness, no broad friendly smile

首帧提示词：`prompts/first_frame/C06_linwan_push_palm.txt`；视频提示词：`prompts/video/C06_linwan_push_palm.txt`。

必须实测的事件：手掌朝前, 手臂完全推出, 收手站稳。事件时间不得从提示词抄成测量结果。

交付 `output/animations/C06_linwan_push_palm/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
