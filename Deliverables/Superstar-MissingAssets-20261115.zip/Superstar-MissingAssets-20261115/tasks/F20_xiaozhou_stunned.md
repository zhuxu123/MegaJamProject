# F20_xiaozhou_stunned — 愣住表情待机

优先级：P1；类型：expression；人物：助理小周；循环：True。

复用剧情段落：[4]。依赖：['REF_xiaozhou']。

动作：Maintain the specified facial expression throughout a subtle breathing loop. Natural small eye movement is allowed; keep the expression readable on every 5 fps frame. Never morph between emotions.

表情：raised brows, widened eyes, slightly open frozen mouth

首帧提示词：`prompts/first_frame/F20_xiaozhou_stunned.txt`；视频提示词：`prompts/video/F20_xiaozhou_stunned.txt`。

必须实测的事件：cycle_start, opposite_phase, cycle_return。事件时间不得从提示词抄成测量结果。

交付 `output/animations/F20_xiaozhou_stunned/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
