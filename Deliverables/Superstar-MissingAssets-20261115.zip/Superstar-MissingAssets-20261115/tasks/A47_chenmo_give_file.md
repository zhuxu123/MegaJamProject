# A47_chenmo_give_file — 递交文件

优先级：P1；类型：action；人物：陈默；循环：False。

复用剧情段落：[32]。依赖：['REF_chenmo']。

动作：Offer a thin neutral gray document folder with both hands to an offscreen recipient, release at the shared transfer point and retract.

表情：serious supportive expression

首帧提示词：`prompts/first_frame/A47_chenmo_give_file.txt`；视频提示词：`prompts/video/A47_chenmo_give_file.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A47_chenmo_give_file/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
