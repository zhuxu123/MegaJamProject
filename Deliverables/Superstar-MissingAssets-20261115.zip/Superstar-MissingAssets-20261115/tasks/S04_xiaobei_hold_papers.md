# S04_xiaobei_hold_papers — 抱资料站立待机循环 / 待机基线偏低

优先级：P0；类型：repair；人物：小北；循环：True。

复用剧情段落：[14]。依赖：['C05_xiaobei_rise_papers']。

动作：Begin very subtle rhythmic breathing at 0.00 seconds, remaining fully standing with both feet planted and both hands securely holding the same three-sheet stack. Repeat a smooth two-second idle cycle. Return to the same pose and motion phase at each boundary. Do not let papers drift, change count, fold or disappear. Do not start running. Match the corrected C05 endpoint and S02 ground baseline, while preserving the breathing loop.

表情：tense distressed eyes, no cheerful smile

首帧提示词：`prompts/first_frame/S04_xiaobei_hold_papers.txt`；视频提示词：`prompts/video/S04_xiaobei_hold_papers.txt`。

必须实测的事件：站姿呼吸循环, 资料始终被双手握住。事件时间不得从提示词抄成测量结果。

交付 `output/animations/S04_xiaobei_hold_papers/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
