# A48_linwan_receive_file — 接过文件

优先级：P1；类型：action；人物：林晚；循环：False。

复用剧情段落：[32]。依赖：先锁定角色母版。

动作：Reach with both hands to receive the same thin gray folder, then hold it securely against the torso.

表情：quiet concentration and guarded resolve

首帧提示词：`prompts/first_frame/A48_linwan_receive_file.txt`；视频提示词：`prompts/video/A48_linwan_receive_file.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A48_linwan_receive_file/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
