# A50_linwan_speak — 面对手机坦诚讲述

优先级：P1；类型：action；人物：林晚；循环：True。

复用剧情段落：[33, 34, 35, 36]。依赖：['A49_linwan_deep_breath']。

动作：Look toward a fixed offscreen phone lens with subtle natural mouth movement and breathing; small restrained conversational hand gestures. No invented words or lip-synced sentence.

表情：calm candid resolve; avoid cheerful chatter

首帧提示词：`prompts/first_frame/A50_linwan_speak.txt`；视频提示词：`prompts/video/A50_linwan_speak.txt`。

必须实测的事件：cycle_start, opposite_phase, cycle_return。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A50_linwan_speak/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
