# A04_linwan_advance — 逼近一步

优先级：P1；类型：action；人物：林晚；循环：False。

复用剧情段落：[3]。依赖：先锁定角色母版。

动作：Advance one small step toward screen right, stop firmly and lean slightly forward.

表情：angry assertive stare without a smile

首帧提示词：`prompts/first_frame/A04_linwan_advance.txt`；视频提示词：`prompts/video/A04_linwan_advance.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A04_linwan_advance/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
