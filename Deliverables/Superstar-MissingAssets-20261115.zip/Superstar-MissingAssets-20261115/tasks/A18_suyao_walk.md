# A18_suyao_walk — 轻快走近

优先级：P1；类型：action；人物：苏瑶；循环：True。

复用剧情段落：[16, 27]。依赖：先锁定角色母版。

动作：Walk in place facing screen left with light restrained steps; preserve both braids and the short coral dress.

表情：sweet social smile

首帧提示词：`prompts/first_frame/A18_suyao_walk.txt`；视频提示词：`prompts/video/A18_suyao_walk.txt`。

必须实测的事件：cycle_start, opposite_phase, cycle_return。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A18_suyao_walk/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
