# C08_suyao_fall_kneel — 失衡跌落跪坐 / 摔倒时的表情不符

优先级：P0；类型：repair；人物：苏瑶；循环：False。

复用剧情段落：[17]。依赖：['baseline:S03_suyao_idle']。

动作：Start a small loss of balance immediately at 0.00 seconds, as though the hem has briefly snagged offscreen. From 0.00–1.20 seconds she tilts and brings her hands forward for balance. From 1.20–2.60 seconds bend both knees and descend in one controlled cartoon fall. From 2.60–3.40 seconds settle into a clear kneeling seated pose, hips resting toward the heels, knees on the invisible floor. From 3.40 seconds onward remain kneeling with a startled but composed expression. Keep the skirt modestly covering the thighs and knees as naturally possible; no upskirt viewpoint. Do not change the skirt length to a gown and do not stand up within this clip. Preserve the valid losing-balance and kneeling motion, but replace the persistent sweet smile with a visibly interrupted smile, widened eyes and startled shame. If reliable facial editing is unavailable, regenerate this clip with the same action and endpoint. Do not add shoulder clutching from act three.

表情：shocked shame with tightened lips, no sustained sweet smile during the fall or rise

首帧提示词：`prompts/first_frame/C08_suyao_fall_kneel.txt`；视频提示词：`prompts/video/C08_suyao_fall_kneel.txt`。

必须实测的事件：身体失衡, 双膝下降, 跪坐落地, 跪坐稳定。事件时间不得从提示词抄成测量结果。

交付 `output/animations/C08_suyao_fall_kneel/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
