# A05_limou_applaud — 导演鼓掌

优先级：P1；类型：action；人物：李谋 / 片场导演；循环：True。

复用剧情段落：[3]。依赖：['REF_limou']。

动作：Applaud rhythmically at chest height in place, hands clearly separating between claps.

表情：satisfied approving smile

首帧提示词：`prompts/first_frame/A05_limou_applaud.txt`；视频提示词：`prompts/video/A05_limou_applaud.txt`。

必须实测的事件：cycle_start, opposite_phase, cycle_return。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A05_limou_applaud/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
