# A10_xiaozhou_release_umbrella — 松手后愣住

优先级：P1；类型：action；人物：助理小周；循环：False。

复用剧情段落：[4]。依赖：['REF_xiaozhou']。

动作：Extend the held closed umbrella toward an offscreen partner, release at the shared transfer event, retract the empty hand and remain stunned.

表情：raised brows, slightly open mouth, frozen surprise

首帧提示词：`prompts/first_frame/A10_xiaozhou_release_umbrella.txt`；视频提示词：`prompts/video/A10_xiaozhou_release_umbrella.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A10_xiaozhou_release_umbrella/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
