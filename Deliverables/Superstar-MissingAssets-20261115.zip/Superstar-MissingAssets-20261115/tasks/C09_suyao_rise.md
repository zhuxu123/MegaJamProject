# C09_suyao_rise — 从跪坐起立 / 裙边黄绿污染

优先级：P0；类型：repair；人物：苏瑶；循环：False。

复用剧情段落：[19]。依赖：['C08_suyao_fall_kneel']。

动作：Begin getting up immediately at 0.00 seconds. From 0.00–1.20 seconds shift forward and plant one foot. From 1.20–2.80 seconds rise with a controlled weight transfer, arms slightly out for balance. From 2.80–3.80 seconds stand upright and settle the pink dress naturally. From 3.80 seconds onward hold a balanced standing pose, both feet on the same ground baseline. No new fall, jump, spin or costume change. Clean contaminated pink dress edges without punching holes or removing fabric. Preserve the existing valid front-foot support action.

表情：shocked shame with tightened lips, no sustained sweet smile during the fall or rise

首帧提示词：`prompts/first_frame/C09_suyao_rise.txt`；视频提示词：`prompts/video/C09_suyao_rise.txt`。

必须实测的事件：脚掌支撑, 由跪姿上升, 站直, 裙摆稳定。事件时间不得从提示词抄成测量结果。

交付 `output/animations/C09_suyao_rise/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
