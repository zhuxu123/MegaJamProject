# A07_linwan_lookback_smirk — 回头冷笑

优先级：P1；类型：action；人物：林晚；循环：False。

复用剧情段落：[4, 15]。依赖：先锁定角色母版。

动作：From a neutral three-quarter stance glance back over the shoulder, then lift just one corner of the mouth and settle.

表情：asymmetrical cold smirk and slightly narrowed eyes, never a friendly broad grin

首帧提示词：`prompts/first_frame/A07_linwan_lookback_smirk.txt`；视频提示词：`prompts/video/A07_linwan_lookback_smirk.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A07_linwan_lookback_smirk/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
