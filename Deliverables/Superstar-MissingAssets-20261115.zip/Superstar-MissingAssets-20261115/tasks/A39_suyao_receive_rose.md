# A39_suyao_receive_rose — 苏瑶接白玫瑰

优先级：P1；类型：action；人物：苏瑶；循环：False。

复用剧情段落：[28, 29]。依赖：先锁定角色母版。

动作：Reach to accept exactly one white rose at the shared contact point and bring it to chest height, keeping it visible.

表情：polite sweet smile with watchful eyes

首帧提示词：`prompts/first_frame/A39_suyao_receive_rose.txt`；视频提示词：`prompts/video/A39_suyao_receive_rose.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A39_suyao_receive_rose/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
