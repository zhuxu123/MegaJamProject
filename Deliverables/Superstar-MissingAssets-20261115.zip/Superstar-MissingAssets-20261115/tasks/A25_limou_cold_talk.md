# A25_limou_cold_talk — 再次低声开口

优先级：P1；类型：action；人物：李谋 / 片场导演；循环：False。

复用剧情段落：[22]。依赖：['REF_limou']。

动作：Turn the head slightly toward the offscreen woman and speak in a restrained low manner without readable words, keeping the body still.

表情：cold calculating eyes and compressed brow

首帧提示词：`prompts/first_frame/A25_limou_cold_talk.txt`；视频提示词：`prompts/video/A25_limou_cold_talk.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A25_limou_cold_talk/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
