# A03_actress_retreat_table — 后退撞桌撑住

优先级：P1；类型：action；人物：第一幕女主演员；循环：False。

复用剧情段落：[2]。依赖：['REF_actress']。

动作：Take two short backward steps, stop abruptly as the lower back reaches an invisible desk edge, arch back and plant both palms behind at the same tabletop height. Hold the braced state.

表情：eyes widen, eyebrows rise, lips part with fear

首帧提示词：`prompts/first_frame/A03_actress_retreat_table.txt`；视频提示词：`prompts/video/A03_actress_retreat_table.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A03_actress_retreat_table/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
