# C07_linwan_stamp — 单次抬脚跺脚 / 悬腿停顿与腿边污染

优先级：P0；类型：repair；人物：林晚；循环：False。

复用剧情段落：[17]。依赖：先锁定角色母版。

动作：Immediately lift the right foot during 0.00–0.40 seconds, reach a brief clear raised-foot phase at about 0.40 seconds, and make one decisive grounded stamp by approximately 0.80 seconds. Keep the foot planted through 1.20 seconds, recover balance by 1.80 seconds, then remain still. Do not sustain the raised leg, jump, kick sideways or repeat the stamp. Clean yellow-green edge contamination without eroding the shoe or leg.

表情：controlled guarded coldness, no broad friendly smile

首帧提示词：`prompts/first_frame/C07_linwan_stamp.txt`；视频提示词：`prompts/video/C07_linwan_stamp.txt`。

必须实测的事件：右脚离地, 右脚悬空, 右脚落地, 身体压低后恢复。事件时间不得从提示词抄成测量结果。

交付 `output/animations/C07_linwan_stamp/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
