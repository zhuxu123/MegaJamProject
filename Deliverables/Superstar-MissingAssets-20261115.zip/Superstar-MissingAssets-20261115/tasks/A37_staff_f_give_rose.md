# A37_staff_f_give_rose — 工作人员递白玫瑰

优先级：P1；类型：action；人物：路人女；循环：False。

复用剧情段落：[28]。依赖：先锁定角色母版。

动作：Without clipboard or pen for this task, extend one white rose toward an offscreen recipient, release at the transfer event and retract the empty hand. Preserve the uniform and intentionally featureless face.

表情：featureless original face; convey neutral professionalism only through posture

首帧提示词：`prompts/first_frame/A37_staff_f_give_rose.txt`；视频提示词：`prompts/video/A37_staff_f_give_rose.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A37_staff_f_give_rose/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
