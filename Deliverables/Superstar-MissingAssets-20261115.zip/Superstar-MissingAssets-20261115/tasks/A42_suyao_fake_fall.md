# A42_suyao_fake_fall — 捂肩后倒跪地

优先级：P1；类型：action；人物：苏瑶；循环：False。

复用剧情段落：[30]。依赖：['A39_suyao_receive_rose']。

动作：Before any contact, recoil as if startled, bring one hand to the shoulder and lower safely into a kneeling seated pose. Keep the white rose in the other hand or release it once with a recorded event.

表情：exaggerated fear and sudden alarm, no wound or blood

首帧提示词：`prompts/first_frame/A42_suyao_fake_fall.txt`；视频提示词：`prompts/video/A42_suyao_fake_fall.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A42_suyao_fake_fall/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
