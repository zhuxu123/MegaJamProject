# A15_linwan_phone_photo — 拿手机偷拍

优先级：P1；类型：action；人物：林晚；循环：False。

复用剧情段落：[6]。依赖：先锁定角色母版。

动作：Raise a charcoal smartphone vertically from chest height to a photographing position, aim to screen left, tap the shutter once and lower slightly.

表情：focused guarded eyes, no smile

首帧提示词：`prompts/first_frame/A15_linwan_phone_photo.txt`；视频提示词：`prompts/video/A15_linwan_phone_photo.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A15_linwan_phone_photo/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
