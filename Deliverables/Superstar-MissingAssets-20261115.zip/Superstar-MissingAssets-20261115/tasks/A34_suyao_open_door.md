# A34_suyao_open_door — 推门入场

优先级：P1；类型：action；人物：苏瑶；循环：False。

复用剧情段落：[27]。依赖：先锁定角色母版。

动作：Push an invisible door with one palm, take one small step and settle facing screen left.

表情：bright sweet smile

首帧提示词：`prompts/first_frame/A34_suyao_open_door.txt`；视频提示词：`prompts/video/A34_suyao_open_door.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A34_suyao_open_door/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
