# A36_linwan_stand_confront — 站起直视不退

优先级：P1；类型：action；人物：林晚；循环：False。

复用剧情段落：[28]。依赖：['A27_linwan_mirror_idle']。

动作：From the seated A27 pose stand upright in one controlled action, face screen right and hold the ground without stepping back.

表情：steady alert eyes and defiant composure

首帧提示词：`prompts/first_frame/A36_linwan_stand_confront.txt`；视频提示词：`prompts/video/A36_linwan_stand_confront.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A36_linwan_stand_confront/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
