# A38_staff_m_give_knife — 工作人员递道具刀

优先级：P1；类型：action；人物：路人男；循环：False。

复用剧情段落：[28]。依赖：先锁定角色母版。

动作：Hold a blunt silver theatrical prop knife by its safe blade housing, offer the handle toward an offscreen recipient and release at the transfer event. Preserve the featureless face.

表情：featureless original face; neutral body posture

首帧提示词：`prompts/first_frame/A38_staff_m_give_knife.txt`；视频提示词：`prompts/video/A38_staff_m_give_knife.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A38_staff_m_give_knife/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
