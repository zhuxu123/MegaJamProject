# A29_chenmo_knock — 轻敲两下门

优先级：P1；类型：action；人物：陈默；循环：False。

复用剧情段落：[24]。依赖：['REF_chenmo']。

动作：Raise the right hand and knock exactly twice on an invisible door at shoulder height, then lower the hand.

表情：polite calm expression

首帧提示词：`prompts/first_frame/A29_chenmo_knock.txt`；视频提示词：`prompts/video/A29_chenmo_knock.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A29_chenmo_knock/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
