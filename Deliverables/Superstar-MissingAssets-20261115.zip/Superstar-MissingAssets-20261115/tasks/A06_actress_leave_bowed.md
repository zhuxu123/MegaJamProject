# A06_actress_leave_bowed — 低头离开

优先级：P1；类型：action；人物：第一幕女主演员；循环：True。

复用剧情段落：[3]。依赖：['REF_actress']。

动作：Walk in place facing screen left with the chin lowered, shoulders drawn in and arms close to the body.

表情：subdued frightened eyes looking downward

首帧提示词：`prompts/first_frame/A06_actress_leave_bowed.txt`；视频提示词：`prompts/video/A06_actress_leave_bowed.txt`。

必须实测的事件：cycle_start, opposite_phase, cycle_return。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A06_actress_leave_bowed/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
