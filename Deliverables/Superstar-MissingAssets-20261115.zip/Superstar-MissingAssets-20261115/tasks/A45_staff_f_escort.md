# A45_staff_f_escort — 女工作人员带离

优先级：P1；类型：action；人物：路人女；循环：True。

复用剧情段落：[31]。依赖：先锁定角色母版。

动作：Walk in place toward screen left with one empty hand at a fixed offscreen upper-arm grip point; no clipboard or pen. Match A44 cadence.

表情：featureless face unchanged

首帧提示词：`prompts/first_frame/A45_staff_f_escort.txt`；视频提示词：`prompts/video/A45_staff_f_escort.txt`。

必须实测的事件：cycle_start, opposite_phase, cycle_return。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A45_staff_f_escort/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
