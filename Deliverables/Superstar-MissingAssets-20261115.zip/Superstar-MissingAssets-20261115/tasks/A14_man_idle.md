# A14_man_idle — 男人路灯待机

优先级：P1；类型：action；人物：路灯下的男人；循环：True。

复用剧情段落：[6]。依赖：['REF_man']。

动作：Stand in place facing screen left, subtle breathing and attentive posture.

表情：quiet restrained expression

首帧提示词：`prompts/first_frame/A14_man_idle.txt`；视频提示词：`prompts/video/A14_man_idle.txt`。

必须实测的事件：cycle_start, opposite_phase, cycle_return。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A14_man_idle/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
