# A49_linwan_deep_breath — 直播前深呼吸

优先级：P1；类型：action；人物：林晚；循环：False。

复用剧情段落：[33]。依赖：先锁定角色母版。

动作：Face front three-quarter toward camera, inhale once visibly through a small chest rise, exhale slowly and settle into an upright speaking stance.

表情：determination calming into honest openness

首帧提示词：`prompts/first_frame/A49_linwan_deep_breath.txt`；视频提示词：`prompts/video/A49_linwan_deep_breath.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A49_linwan_deep_breath/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
