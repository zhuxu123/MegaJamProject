# A32_linwan_seated_turn — 回头怀疑动摇

优先级：P1；类型：action；人物：林晚；循环：False。

复用剧情段落：[25]。依赖：['A27_linwan_mirror_idle']。

动作：From the same seated pose turn the head and upper torso toward screen left, pause with a questioning look, then soften slightly.

表情：one brow lifts; suspicion gradually eases into uncertainty

首帧提示词：`prompts/first_frame/A32_linwan_seated_turn.txt`；视频提示词：`prompts/video/A32_linwan_seated_turn.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A32_linwan_seated_turn/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
