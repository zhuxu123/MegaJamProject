# A01_linwan_walk — 稳定行走

优先级：P1；类型：action；人物：林晚；循环：True。

复用剧情段落：[1, 3, 15, 20, 21, 39]。依赖：先锁定角色母版。

动作：Walk in place with a steady heel-to-toe gait and natural arm swing, maintaining a fixed root position.

表情：calm controlled confidence

首帧提示词：`prompts/first_frame/A01_linwan_walk.txt`；视频提示词：`prompts/video/A01_linwan_walk.txt`。

必须实测的事件：cycle_start, opposite_phase, cycle_return。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A01_linwan_walk/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
