# A52_xiaobei_brave_walk — 勇敢走进直播

优先级：P1；类型：action；人物：小北；循环：True。

复用剧情段落：[35]。依赖：先锁定角色母版。

动作：Walk in place toward screen left with restrained short steps and empty hands, keeping shoulders upright despite tension.

表情：watery eyes at the edge of tears but determined gaze

首帧提示词：`prompts/first_frame/A52_xiaobei_brave_walk.txt`；视频提示词：`prompts/video/A52_xiaobei_brave_walk.txt`。

必须实测的事件：cycle_start, opposite_phase, cycle_return。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A52_xiaobei_brave_walk/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
