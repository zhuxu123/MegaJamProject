# A13_xiaoxia_idle — 小夏路灯待机

优先级：P1；类型：action；人物：小夏；循环：True。

复用剧情段落：[6]。依赖：['REF_xiaoxia']。

动作：Stand in place with subtle breathing, looking toward a man to screen right.

表情：quiet serious attention

首帧提示词：`prompts/first_frame/A13_xiaoxia_idle.txt`；视频提示词：`prompts/video/A13_xiaoxia_idle.txt`。

必须实测的事件：cycle_start, opposite_phase, cycle_return。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A13_xiaoxia_idle/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
