# A24_suyao_angry_talk — 愤怒提及小北

优先级：P1；类型：action；人物：苏瑶；循环：False。

复用剧情段落：[22]。依赖：先锁定角色母版。

动作：Lean slightly toward an offscreen man and speak urgently with a short frustrated hand motion, ending in a tense hold. No invented audible words.

表情：furrowed brows, tight mouth and flashes of anger

首帧提示词：`prompts/first_frame/A24_suyao_angry_talk.txt`；视频提示词：`prompts/video/A24_suyao_angry_talk.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A24_suyao_angry_talk/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
