# A43_suyao_kneel_accuse — 泪眼指认

优先级：P1；类型：action；人物：苏瑶；循环：True。

复用剧情段落：[30, 31]。依赖：['A42_suyao_fake_fall']。

动作：Remain in the kneeling endpoint of A42, one hand over the shoulder, the other pointing toward screen left; subtle breathing without changing the pointing target.

表情：watery eyes and staged frightened grievance

首帧提示词：`prompts/first_frame/A43_suyao_kneel_accuse.txt`；视频提示词：`prompts/video/A43_suyao_kneel_accuse.txt`。

必须实测的事件：cycle_start, opposite_phase, cycle_return。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A43_suyao_kneel_accuse/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
