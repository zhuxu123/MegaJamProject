# A46_staff_m_escort — 男工作人员带离

优先级：P1；类型：action；人物：路人男；循环：True。

复用剧情段落：[31]。依赖：['A55_staff_m_take_knife']。

动作：Walk in place toward screen left with one hand at the opposite upper-arm grip point, the other securing the prop knife away from bodies. Match A44 cadence.

表情：featureless face unchanged

首帧提示词：`prompts/first_frame/A46_staff_m_escort.txt`；视频提示词：`prompts/video/A46_staff_m_escort.txt`。

必须实测的事件：cycle_start, opposite_phase, cycle_return。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A46_staff_m_escort/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
