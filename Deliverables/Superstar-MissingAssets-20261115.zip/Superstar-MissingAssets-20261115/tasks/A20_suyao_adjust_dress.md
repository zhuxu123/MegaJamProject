# A20_suyao_adjust_dress — 整理裙摆重新甜笑

优先级：P1；类型：action；人物：苏瑶；循环：False。

复用剧情段落：[19]。依赖：['C09_suyao_rise']。

动作：Begin standing at the C09 endpoint; smooth the short dress hem with both hands, straighten the torso and bring back a social smile.

表情：visible progression from shame and resentment to a controlled sweet smile

首帧提示词：`prompts/first_frame/A20_suyao_adjust_dress.txt`；视频提示词：`prompts/video/A20_suyao_adjust_dress.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A20_suyao_adjust_dress/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
