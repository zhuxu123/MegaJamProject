# A30_linwan_mirror_glance — 从镜中看陈默

优先级：P1；类型：action；人物：林晚；循环：False。

复用剧情段落：[24]。依赖：['A27_linwan_mirror_idle']。

动作：Keep the A27 seated torso facing away; shift only the eyes and slightly lift the chin to notice someone in the offscreen mirror.

表情：guarded curiosity, no full turn

首帧提示词：`prompts/first_frame/A30_linwan_mirror_glance.txt`；视频提示词：`prompts/video/A30_linwan_mirror_glance.txt`。

必须实测的事件：action_onset, main_event, settled_end。事件时间不得从提示词抄成测量结果。

交付 `output/animations/A30_linwan_mirror_glance/frames/` + animation.json + 源视频/首帧/提交图/提示词/真实审核记录。若为表情任务，另从已验收序列选一帧保存 expression.png，不额外拼接头像到身体。
