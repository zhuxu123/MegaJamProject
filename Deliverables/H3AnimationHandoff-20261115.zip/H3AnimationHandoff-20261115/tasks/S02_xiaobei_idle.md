# 小北 站立待机循环

任务 ID：`S02_xiaobei_idle`。必做。类型：循环。来源：配套制作默认 基础待机。

参考图：[已纠正人物参考](../references/xiaobei.png)。

前置动作：`无，可独立制作首帧`。首帧落盘路径：`inputs/S02_xiaobei_idle.png`。

## 起始姿态

A relaxed standing pose in three-quarter view facing screen right, both feet fully grounded. Keep the character's specified accessories. No plot papers or photo are present.

## 动作时间安排

Start a subtle repeating idle immediately at 0.00 seconds. Keep both feet planted, with gentle breathing and very small natural hair and clothing motion. Return smoothly to the initial body height, shoulder angle, accessory position and motion direction every two seconds. No gesture, turn, step or change in facial design. Characters with drawn eyes may blink once per complete cycle, fully reopening them before the cycle boundary; featureless characters remain featureless.

时间安排为生成目标，实际有效起止点必须通过源帧检查获得。

## 必查事件

- 呼吸周期
- 双脚位置固定
- 相同姿态和运动方向回到起相位

## 执行文件

- [首帧制作提示词](../prompts/first_frame/S02_xiaobei_idle.txt)
- [完整视频提示词](../prompts/video/S02_xiaobei_idle.txt)
- [已填提示词的单条 API 图](../workflows/jobs/S02_xiaobei_idle.json)

独立 API 图的 LoadImage 路径需先放置或上传首帧；推荐由 comfy_jobs.py 自动上传并保存返回路径。提交时不自行将 24 FPS 改为 5。
