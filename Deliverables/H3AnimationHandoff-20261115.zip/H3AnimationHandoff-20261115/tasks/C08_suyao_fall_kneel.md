# 苏瑶 失衡跌落跪坐

任务 ID：`C08_suyao_fall_kneel`。必做。类型：一次性。来源：需求第3场 苏瑶摔倒跪坐。

参考图：[已纠正人物参考](../references/suyao.jpg)。

前置动作：`S03_suyao_idle`。首帧落盘路径：`inputs/C08_suyao_fall_kneel.png`。

## 起始姿态

Three-quarter view facing screen left, upright with both feet grounded and arms free. Preserve her pink short flared dress, pink heels and two braids. No other person or visible pulling hand.

## 动作时间安排

Start a small loss of balance immediately at 0.00 seconds, as though the hem has briefly snagged offscreen. From 0.00–1.20 seconds she tilts and brings her hands forward for balance. From 1.20–2.60 seconds bend both knees and descend in one controlled cartoon fall. From 2.60–3.40 seconds settle into a clear kneeling seated pose, hips resting toward the heels, knees on the invisible floor. From 3.40 seconds onward remain kneeling with a startled but composed expression. Keep the skirt modestly covering the thighs and knees as naturally possible; no upskirt viewpoint. Do not change the skirt length to a gown and do not stand up within this clip.

时间安排为生成目标，实际有效起止点必须通过源帧检查获得。

## 必查事件

- 身体失衡
- 双膝下降
- 跪坐落地
- 跪坐稳定

## 执行文件

- [首帧制作提示词](../prompts/first_frame/C08_suyao_fall_kneel.txt)
- [完整视频提示词](../prompts/video/C08_suyao_fall_kneel.txt)
- [已填提示词的单条 API 图](../workflows/jobs/C08_suyao_fall_kneel.json)

独立 API 图的 LoadImage 路径需先放置或上传首帧；推荐由 comfy_jobs.py 自动上传并保存返回路径。提交时不自行将 24 FPS 改为 5。
