# 林晚 抬手到眼前并撕照片

任务 ID：`C01_linwan_tear_photo`。必做。类型：一次性。来源：需求第1场 林晚动作。

参考图：[已纠正人物参考](../references/linwan.jpg)。

前置动作：`无，可独立制作首帧`。首帧落盘路径：`inputs/C01_linwan_tear_photo.png`。

## 起始姿态

Three-quarter view facing screen right, feet grounded. Both hands already hold the two upper corners of ONE small matte rectangular photo at upper-chest height, elbows bent, ready to raise it. The photo has a neutral gray back and no readable text; no wall is present.

## 动作时间安排

At 0.00 seconds she is already in the ready pose and immediately lifts the held photo to eye height during 0.00–0.80 seconds. From 0.80–1.60 seconds her hands firmly grip opposite sides, making the intent clearly readable. From 1.60–2.60 seconds she tears the photo once down the middle; the paper visibly separates into exactly two pieces. From 2.60–4.20 seconds she moves the pieces apart and slightly lowers them. From 4.20 seconds onward she holds one piece in each hand. Do not repair the photo or repeat the tear.

时间安排为生成目标，实际有效起止点必须通过源帧检查获得。

## 必查事件

- 抬手到眼前
- 两手抓住同一张照片
- 照片撕裂并分成两片
- 末尾两手各持一片

## 执行文件

- [首帧制作提示词](../prompts/first_frame/C01_linwan_tear_photo.txt)
- [完整视频提示词](../prompts/video/C01_linwan_tear_photo.txt)
- [已填提示词的单条 API 图](../workflows/jobs/C01_linwan_tear_photo.json)

独立 API 图的 LoadImage 路径需先放置或上传首帧；推荐由 comfy_jobs.py 自动上传并保存返回路径。提交时不自行将 24 FPS 改为 5。
