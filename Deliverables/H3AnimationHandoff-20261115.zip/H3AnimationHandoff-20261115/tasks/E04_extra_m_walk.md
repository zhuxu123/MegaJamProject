# 路人男 原地走路循环

任务 ID：`E04_extra_m_walk`。必做。类型：循环。来源：用户补充 路人待机和走路必做。

参考图：[已纠正人物参考](../references/extra_m.jpg)。

前置动作：`无，可独立制作首帧`。首帧落盘路径：`inputs/E04_extra_m_walk.png`。

## 起始姿态

Three-quarter view facing screen right, already at left-foot forward ground-contact phase in a walking cycle; preserve all character accessories and their hand assignment.

## 动作时间安排

Begin a steady in-place walk at 0.00 seconds. Alternate clear left and right foot contacts at a relaxed pace, with modest hip motion and natural arm movement allowed by held props. Keep a stationary screen-space root and constant screen-right facing direction. For the woman, the left hand keeps the clipboard and the right hand keeps the pen throughout; no swapping or new props. Complete repeated left-plus-right gait cycles, returning to the same foot phase and motion direction each cycle. Do not turn, stop, walk out of frame, or invent facial features.

时间安排为生成目标，实际有效起止点必须通过源帧检查获得。

## 必查事件

- 左脚着地
- 右脚着地
- 完整左右步周期
- 道具与无五官特征保持

## 执行文件

- [首帧制作提示词](../prompts/first_frame/E04_extra_m_walk.txt)
- [完整视频提示词](../prompts/video/E04_extra_m_walk.txt)
- [已填提示词的单条 API 图](../workflows/jobs/E04_extra_m_walk.json)

独立 API 图的 LoadImage 路径需先放置或上传首帧；推荐由 comfy_jobs.py 自动上传并保存返回路径。提交时不自行将 24 FPS 改为 5。
