# 小北 抱资料从跪姿起立

任务 ID：`C05_xiaobei_rise_papers`。必做。类型：一次性。来源：需求第2场 收拾材料起立 拆分后半。

参考图：[已纠正人物参考](../references/xiaobei.png)。

前置动作：`C04_xiaobei_collect_papers`。首帧落盘路径：`inputs/C05_xiaobei_rise_papers.png`。

## 起始姿态

Use the final accepted stable frame of C04, kneeling with the collected THREE-sheet stack secured in both hands. No loose paper remains on the ground.

## 动作时间安排

Begin rising immediately at 0.00 seconds. From 0.00–1.20 seconds plant one foot while maintaining the paper grip. From 1.20–2.80 seconds shift weight and push up smoothly. From 2.80–3.80 seconds straighten both legs, returning to a balanced standing pose. Keep the stack held against her chest without changing its count or size. From 3.80 seconds onward hold that standing pose with very subtle breathing. Do not drop paper, run, or kneel again.

时间安排为生成目标，实际有效起止点必须通过源帧检查获得。

## 必查事件

- 单脚支撑
- 身体上升
- 双腿站直
- 持资料站稳

## 执行文件

- [首帧制作提示词](../prompts/first_frame/C05_xiaobei_rise_papers.txt)
- [完整视频提示词](../prompts/video/C05_xiaobei_rise_papers.txt)
- [已填提示词的单条 API 图](../workflows/jobs/C05_xiaobei_rise_papers.json)

独立 API 图的 LoadImage 路径需先放置或上传首帧；推荐由 comfy_jobs.py 自动上传并保存返回路径。提交时不自行将 24 FPS 改为 5。
