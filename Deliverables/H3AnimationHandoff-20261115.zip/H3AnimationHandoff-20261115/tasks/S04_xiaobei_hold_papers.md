# 小北 抱资料站立待机循环

任务 ID：`S04_xiaobei_hold_papers`。必做。类型：循环。来源：配套制作默认 起立后的衔接。

参考图：[已纠正人物参考](../references/xiaobei.png)。

前置动作：`C05_xiaobei_rise_papers`。首帧落盘路径：`inputs/S04_xiaobei_hold_papers.png`。

## 起始姿态

Use the accepted standing end frame of C05, keeping exactly the same THREE-sheet stack against the chest and screen-right orientation.

## 动作时间安排

Begin very subtle rhythmic breathing at 0.00 seconds, remaining fully standing with both feet planted and both hands securely holding the same three-sheet stack. Repeat a smooth two-second idle cycle. Return to the same pose and motion phase at each boundary. Do not let papers drift, change count, fold or disappear. Do not start running.

时间安排为生成目标，实际有效起止点必须通过源帧检查获得。

## 必查事件

- 站姿呼吸循环
- 资料始终被双手握住

## 执行文件

- [首帧制作提示词](../prompts/first_frame/S04_xiaobei_hold_papers.txt)
- [完整视频提示词](../prompts/video/S04_xiaobei_hold_papers.txt)
- [已填提示词的单条 API 图](../workflows/jobs/S04_xiaobei_hold_papers.json)

独立 API 图的 LoadImage 路径需先放置或上传首帧；推荐由 comfy_jobs.py 自动上传并保存返回路径。提交时不自行将 24 FPS 改为 5。
