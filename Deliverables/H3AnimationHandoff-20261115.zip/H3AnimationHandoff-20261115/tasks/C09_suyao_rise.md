# 苏瑶 从跪坐起立

任务 ID：`C09_suyao_rise`。必做。类型：一次性。来源：需求第3场 苏瑶起立。

参考图：[已纠正人物参考](../references/suyao.jpg)。

前置动作：`C08_suyao_fall_kneel`。首帧落盘路径：`inputs/C09_suyao_rise.png`。

## 起始姿态

Use the final accepted stable frame of C08 as the exact opening image, with identical kneeling seated pose, pink dress folds, feet, hair and screen-left orientation.

## 动作时间安排

Begin getting up immediately at 0.00 seconds. From 0.00–1.20 seconds shift forward and plant one foot. From 1.20–2.80 seconds rise with a controlled weight transfer, arms slightly out for balance. From 2.80–3.80 seconds stand upright and settle the pink dress naturally. From 3.80 seconds onward hold a balanced standing pose, both feet on the same ground baseline. No new fall, jump, spin or costume change.

时间安排为生成目标，实际有效起止点必须通过源帧检查获得。

## 必查事件

- 脚掌支撑
- 由跪姿上升
- 站直
- 裙摆稳定

## 执行文件

- [首帧制作提示词](../prompts/first_frame/C09_suyao_rise.txt)
- [完整视频提示词](../prompts/video/C09_suyao_rise.txt)
- [已填提示词的单条 API 图](../workflows/jobs/C09_suyao_rise.json)

独立 API 图的 LoadImage 路径需先放置或上传首帧；推荐由 comfy_jobs.py 自动上传并保存返回路径。提交时不自行将 24 FPS 改为 5。
