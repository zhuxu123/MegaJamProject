# 林晚 伸手掌向前推

任务 ID：`C06_linwan_push_palm`。必做。类型：一次性。来源：需求第2场 林晚动作。

参考图：[已纠正人物参考](../references/linwan.jpg)。

前置动作：`无，可独立制作首帧`。首帧落盘路径：`inputs/C06_linwan_push_palm.png`。

## 起始姿态

Three-quarter view facing screen right, grounded standing pose. The right elbow is bent and her open right hand is already at chest height, palm facing screen right, ready to extend. Left hand rests naturally by her side.

## 动作时间安排

Immediately extend the right arm forward from 0.00–1.20 seconds, with the open palm pushing toward screen right. From 1.20–2.00 seconds keep the palm clearly extended and upright, fingers together, elbow not hyperextended. From 2.00–3.60 seconds retract smoothly. From 3.60 seconds onward settle into the initial ready stance. This is an open-palm forward push gesture, not a punch, wave, grab, or actual catch. No second person appears and no paper materializes in her hand.

时间安排为生成目标，实际有效起止点必须通过源帧检查获得。

## 必查事件

- 手掌朝前
- 手臂完全推出
- 收手站稳

## 执行文件

- [首帧制作提示词](../prompts/first_frame/C06_linwan_push_palm.txt)
- [完整视频提示词](../prompts/video/C06_linwan_push_palm.txt)
- [已填提示词的单条 API 图](../workflows/jobs/C06_linwan_push_palm.json)

独立 API 图的 LoadImage 路径需先放置或上传首帧；推荐由 comfy_jobs.py 自动上传并保存返回路径。提交时不自行将 24 FPS 改为 5。
