# 小北 抱资料原地小跑

任务 ID：`C02_xiaobei_jog_papers`。必做。类型：循环。来源：需求第2场 小北拿资料小跑。

参考图：[已纠正人物参考](../references/xiaobei.png)。

前置动作：`无，可独立制作首帧`。首帧落盘路径：`inputs/C02_xiaobei_jog_papers.png`。

## 起始姿态

Three-quarter view facing screen right, already in a running gait phase with the left foot at forward ground contact and the right heel raised. Both hands secure the same stack of exactly THREE ivory A4-size sheets against her chest; no folder.

## 动作时间安排

Start the repeating jog immediately at 0.00 seconds. Jog in place at a steady moderate rhythm, alternating left and right foot contacts with small vertical body motion, while both hands keep the three sheets together against the chest. Maintain the same screen position and direction. Repeat several complete left-plus-right gait cycles. Return to the same foot contact phase, body height, hair motion and paper position at each cycle boundary. Do not stop, turn, stumble or release the sheets.

时间安排为生成目标，实际有效起止点必须通过源帧检查获得。

## 必查事件

- 左脚着地相位
- 右脚着地相位
- 双手抱资料不掉落

## 执行文件

- [首帧制作提示词](../prompts/first_frame/C02_xiaobei_jog_papers.txt)
- [完整视频提示词](../prompts/video/C02_xiaobei_jog_papers.txt)
- [已填提示词的单条 API 图](../workflows/jobs/C02_xiaobei_jog_papers.json)

独立 API 图的 LoadImage 路径需先放置或上传首帧；推荐由 comfy_jobs.py 自动上传并保存返回路径。提交时不自行将 24 FPS 改为 5。
