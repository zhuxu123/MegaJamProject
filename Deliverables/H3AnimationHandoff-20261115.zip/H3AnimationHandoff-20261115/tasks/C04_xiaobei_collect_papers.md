# 小北 跪姿收拾资料

任务 ID：`C04_xiaobei_collect_papers`。必做。类型：一次性。来源：需求第2场 收拾材料起立 拆分前半。

参考图：[已纠正人物参考](../references/xiaobei.png)。

前置动作：`C03_xiaobei_fall_scatter`。首帧落盘路径：`inputs/C04_xiaobei_collect_papers.png`。

## 起始姿态

Use the final accepted stable frame of C03 as the opening image, including the identical kneeling pose and the exact positions and number of all THREE fallen sheets. Do not redraw or relocate them.

## 动作时间安排

Start reaching for the nearest sheet immediately at 0.00 seconds. From 0.00–1.20 seconds touch and grasp the first sheet, then place it into the other hand. From 1.20–2.40 seconds pick up the second sheet with clear hand contact. From 2.40–3.60 seconds collect the last sheet. From 3.60–4.20 seconds align the three sheets into one stack held in both hands at chest height. Remain kneeling and hold the stack to the end. Each sheet leaves the ground only after hand contact; no teleporting or duplicate sheets.

时间安排为生成目标，实际有效起止点必须通过源帧检查获得。

## 必查事件

- 手触碰第一张再拿起
- 第二张拿起
- 最后一张离地
- 三张叠齐且仍跪姿

## 执行文件

- [首帧制作提示词](../prompts/first_frame/C04_xiaobei_collect_papers.txt)
- [完整视频提示词](../prompts/video/C04_xiaobei_collect_papers.txt)
- [已填提示词的单条 API 图](../workflows/jobs/C04_xiaobei_collect_papers.json)

独立 API 图的 LoadImage 路径需先放置或上传首帧；推荐由 comfy_jobs.py 自动上传并保存返回路径。提交时不自行将 24 FPS 改为 5。
