# 苏瑶 跪坐停留循环

任务 ID：`S05_suyao_kneel_idle`。必做。类型：循环。来源：配套制作默认 跌倒与起立间的停留。

参考图：[已纠正人物参考](../references/suyao.jpg)。

前置动作：`C08_suyao_fall_kneel`。首帧落盘路径：`inputs/S05_suyao_kneel_idle.png`。

## 起始姿态

Use the accepted stable kneeling end frame of C08 with exactly the same knee, foot and pink-dress positions.

## 动作时间安排

At 0.00 seconds she is already kneeling and begins only gentle rhythmic breathing, with small shoulder and braid movement. Remain seated toward the heels without moving the knees or feet. Repeat a subtle two-second idle cycle and return to the same pose and motion direction. No standing, collapsing further, turning or costume change.

时间安排为生成目标，实际有效起止点必须通过源帧检查获得。

## 必查事件

- 跪坐呼吸循环
- 膝盖与脚不滑动

## 执行文件

- [首帧制作提示词](../prompts/first_frame/S05_suyao_kneel_idle.txt)
- [完整视频提示词](../prompts/video/S05_suyao_kneel_idle.txt)
- [已填提示词的单条 API 图](../workflows/jobs/S05_suyao_kneel_idle.json)

独立 API 图的 LoadImage 路径需先放置或上传首帧；推荐由 comfy_jobs.py 自动上传并保存返回路径。提交时不自行将 24 FPS 改为 5。
