# 林晚 单次抬脚跺脚

任务 ID：`C07_linwan_stamp`。必做。类型：一次性。来源：需求第3场 林晚动作。

参考图：[已纠正人物参考](../references/linwan.jpg)。

前置动作：`无，可独立制作首帧`。首帧落盘路径：`inputs/C07_linwan_stamp.png`。

## 起始姿态

Three-quarter view facing screen right, left foot bearing weight, right knee slightly prepared to lift, both feet visible. No second character or foreign skirt is baked into this sprite.

## 动作时间安排

Immediately lift the right foot from 0.00–1.00 seconds. From 1.00–1.40 seconds the shoe is clearly suspended above the invisible ground. From 1.40–2.20 seconds stamp the right foot down once, with a short controlled body compression. Keep a clear grounded contact from 2.20–2.80 seconds. From 2.80–4.20 seconds recover to the original standing balance, then remain steady. Do not kick sideways, jump, repeat the stamp, or move the character root sideways.

时间安排为生成目标，实际有效起止点必须通过源帧检查获得。

## 必查事件

- 右脚离地
- 右脚悬空
- 右脚落地
- 身体压低后恢复

## 执行文件

- [首帧制作提示词](../prompts/first_frame/C07_linwan_stamp.txt)
- [完整视频提示词](../prompts/video/C07_linwan_stamp.txt)
- [已填提示词的单条 API 图](../workflows/jobs/C07_linwan_stamp.json)

独立 API 图的 LoadImage 路径需先放置或上传首帧；推荐由 comfy_jobs.py 自动上传并保存返回路径。提交时不自行将 24 FPS 改为 5。
