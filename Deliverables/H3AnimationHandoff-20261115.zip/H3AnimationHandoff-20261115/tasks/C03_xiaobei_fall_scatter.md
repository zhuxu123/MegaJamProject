# 小北 失衡跌倒并散落资料

任务 ID：`C03_xiaobei_fall_scatter`。必做。类型：一次性。来源：需求第2场 小北摔倒散落材料。

参考图：[已纠正人物参考](../references/xiaobei.png)。

前置动作：`C02_xiaobei_jog_papers`。首帧落盘路径：`inputs/C03_xiaobei_fall_scatter.png`。

## 起始姿态

Use a clean matching foot-contact frame from C02 as the exact opening image: same three-quarter screen-right view and THREE held ivory sheets. She is still upright; no falling motion has happened yet.

## 动作时间安排

Immediately at 0.00 seconds her planted foot hesitates and her torso tips forward. From 0.00–1.00 seconds she loses balance visibly. From 1.00–2.00 seconds the two hands separate and release the three sheets, which travel along short visible arcs. From 2.00–3.20 seconds she lowers into a safe cartoon fall, landing on bent knees and bracing hands without injury. From 3.20–4.20 seconds exactly three separate sheets settle on the invisible ground near her hands, all inside the canvas. Then hold the kneeling position and keep all papers still. Preserve a modest skirt silhouette, with no upskirt angle.

时间安排为生成目标，实际有效起止点必须通过源帧检查获得。

## 必查事件

- 身体失衡
- 资料离手
- 纸张在空中
- 双膝和手落地
- 三张资料停在地面

## 执行文件

- [首帧制作提示词](../prompts/first_frame/C03_xiaobei_fall_scatter.txt)
- [完整视频提示词](../prompts/video/C03_xiaobei_fall_scatter.txt)
- [已填提示词的单条 API 图](../workflows/jobs/C03_xiaobei_fall_scatter.json)

独立 API 图的 LoadImage 路径需先放置或上传首帧；推荐由 comfy_jobs.py 自动上传并保存返回路径。提交时不自行将 24 FPS 改为 5。
