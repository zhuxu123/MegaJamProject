# ComfyUI 角色动作视频与透明帧工作流

用一张角色图制作一组构图统一的 2D 游戏动作。每个动作独立生成一条绿幕 MP4，验收后可选导出透明 PNG 序列。走路、待机、拾取、投掷、出拳和撑伞已按此流程完成。

## 1. 准备角色首帧

1. 选全身角色图，优先用透明 PNG。保留发梢、手、鞋和服装边缘。
2. 将角色等比合成到 #00FF00 方形画布。用人物中心和鞋底基线对齐全组素材。本次 640 × 640 的画布中，人物约高 478 像素，鞋底约在 y=570。为开伞留出顶部空间，为抛物和出拳留出侧边空间。
3. 动作要求从第一帧就侧身、握物或看到地上的道具时，将它们做进首帧。沿用正面图时，动作段可写先自然转向再开始动作。
4. 将合成图放到 ComfyUI 的 input 目录，记下相对路径。新动作沿用同一缩放和鞋底基线。

## 2. 为每个动作写一条提示词

从参考词沿用固定机位、全身绿幕、动作节奏和声音写法。人物特征以新项目的首帧为准。各条共享角色外观和镜头约束，分别描述起始姿势、动作、接触或释放、结束姿势。固定绿幕要明确到整个动作的每一帧。

~~~text
For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.

integrated_multimodal_description: [Shot 1] A single fixed full-body shot of the character in <Picture 1> against a flat, evenly lit bright chroma green field. Preserve [face, hair, outfit, proportions and art style]. Keep the entire figure and every prop inside the frame. [Starting pose, action, contact or release, then ending pose.] The background keeps the same bright green color in every frame.

overall_soundscape: [One or two synchronized game sound effects.]

non_diegetic_music: N/A
~~~

| 动作 | 要写清楚的画面 |
| --- | --- |
| 走路 | 固定朝向原地迈步，双脚交替接地，手臂反向摆动。需要循环时，从稳定段截取完整步态周期。 |
| 待机 | 双脚固定，小幅呼吸、眨眼，末尾回到起始姿势。 |
| 捡东西 | 物体在地面有明确位置。手接触、抓握并抬起，站稳仍持物。 |
| 丢东西 | 先看到手里的物体，再离手走一段短抛物线，最后落在画面内。 |
| 打人 | 单角色朝画外做一次卡通出拳，伸拳、收拳、回到站姿。 |
| 撑伞 | 闭伞入画，推开伞面，完全撑开后仍有一只手握住伞柄。 |

## 3. 用 ComfyUI 批量生成

[ComfyUI API 模板](comfyui-h3-i2v-api.json)来自本次成功运行的工作流。它用于提交给 ComfyUI 的 `/prompt` 接口。使用界面时，在原始画布工作流里改下表对应的节点。

| 节点 | 字段 | 换项目时填写 |
| --- | --- | --- |
| `114` Load Image | `image` | 首帧在 ComfyUI input 中的相对路径 |
| `105:104` MiniMax H3 Image to Video | `prompt` | 一条动作的完整提示词 |
| `92` Save Video | `filename_prefix` | `video/项目名/动作名` |
| `105:15` Random Noise | `noise_seed` | 保存用过的种子，补跑时可换种子 |
| `115` Resolution Selector | `aspect_ratio`、`megapixels`、`multiple` | 示例为方形、0.4 MP、32 像素倍数，实测 640 × 640 |
| `105:111` duration | `value` | 示例输入 5 秒，帧数对齐后输出 124 帧，24 fps 下约 5.17 秒 |
| `105:9` Basic Scheduler | `steps` | 示例 20 步 |

确认 ComfyUI 服务可访问，并已装齐模板加载节点指定的扩散模型、文本编码器、视频 VAE 和音频 VAE。可访问 `/system_stats` 检查运行状态，通过 `/object_info/UNETLoader`、`/object_info/CLIPLoader`、`/object_info/VAELoader` 核对模型文件名。

用 PowerShell 7 在模板目录提交一条。将示例路径改成项目实际路径，先测试一个代表动作，确认构图和绿幕，再提交整组。

~~~powershell
$comfy = 'http://127.0.0.1:8188'
$graph = Get-Content -LiteralPath '.\comfyui-h3-i2v-api.json' -Raw | ConvertFrom-Json -AsHashtable
$graph['114'].inputs.image = 'my_project/character_green.png'
$graph['105:104'].inputs.prompt = [IO.File]::ReadAllText((Resolve-Path '.\walk-prompt.txt').Path)
$graph['92'].inputs.filename_prefix = 'video/my_project/01_walk'
$body = @{prompt = $graph} | ConvertTo-Json -Depth 12 -Compress
$job = Invoke-RestMethod "$comfy/prompt" -Method Post -ContentType 'application/json; charset=utf-8' -Body $body
$job.prompt_id
~~~

记录每条的 `prompt_id`。用 `GET /queue` 检查等待与运行状态，用 `GET /history/{prompt_id}` 确认完成或查看错误。执行期间历史可能为空。完成后取 `outputs` 中的实际文件名，从 ComfyUI 输出目录或 `/view` 取片。此次在 RTX 5080 上后续单条约 2.5–3 分钟，首条另需加载模型。

## 4. 验收与补跑

逐条播放并抽看首帧、动作峰值、接触或释放帧、末帧。检查人物一致性、镜头和鞋底位置、出框、手指和道具变形、背景颜色、音效和动作同步。待机和走路如果要循环，再检查首尾接缝。

- **出拳时背景变暗。** 首版从亮绿变成深绿。缩短伸拳与收拳，在提示词中强调所有帧的背景是同一块明亮纯绿，换种子单独补跑。逐帧检查远离人物的背景条带，再抽查伸拳峰值。
- **伞已撑开，手在末尾松开。** 找到伞面完全展开且手仍握伞柄的最后一段。本次选其中一帧替换后面的尾帧，保留原时长与音轨。若末尾要有自然的持伞动作，强化握持指令后重跑，并逐帧检查收尾。
- **物体突然出现或变形。** 将物件放进首帧，分开描述抓住、携带和松手。拾取和投掷需要同一件道具时，给各动作准备各自的起始姿势，并复用同一份道具图。

## 5. 可选导出透明帧

将本目录的 `导出透明动画帧.bat` 和 `extract_green_screen.py` 复制到项目的视频目录，同级放入待处理视频。Windows 环境需能从 PATH 调用 Python 和 FFmpeg，且 Python 已有 Pillow 和 NumPy。双击批处理，回车默认按 5 fps 预览，输入 `0` 导出全部解码帧。出拳和道具离手等短动作优先用高帧率或全帧检查。

每条视频输出一个 PNG 目录，保留原画幅与角色位置。先用浅底和深底检查发梢、手指、脚跟和道具边缘。角色穿绿色服装时留意误抠。游戏端按帧号顺序与导出帧率播放，复查接缝和角色锚点。

交付时随视频保留对应首帧、提示词、种子和 API 工作流。交付透明帧时一并记录导出帧率与鞋底基线。
