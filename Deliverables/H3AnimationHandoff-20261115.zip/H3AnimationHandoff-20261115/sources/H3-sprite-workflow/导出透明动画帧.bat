@echo off
setlocal
python "%~dp0extract_green_screen.py" --interactive
set "export_status=%errorlevel%"
pause
exit /b %export_status%
