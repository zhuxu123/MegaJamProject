"""Sample green-screen videos and export full-size transparent PNGs."""

import argparse
from pathlib import Path
import shutil
import subprocess
import tempfile

import numpy as np
from PIL import Image, ImageFilter


VIDEO_EXTENSIONS = {".mp4", ".mov", ".m4v", ".mkv", ".avi", ".webm"}


def read_frames(stream):
    # FFmpeg's PPM encoder writes a complete header for every RGB frame.
    for signature in iter(stream.readline, b""):
        if signature != b"P6\n":
            raise ValueError("Unexpected frame header from FFmpeg.")
        width, height = map(int, stream.readline().split())
        if stream.readline() != b"255\n":
            raise ValueError("Unexpected pixel depth from FFmpeg.")
        size = width * height * 3
        pixels = stream.read(size)
        if len(pixels) != size:
            raise ValueError("FFmpeg returned an incomplete frame.")
        yield np.frombuffer(pixels, dtype=np.uint8).reshape(height, width, 3)


def remove_green(rgb, foreground, background, feather, despill):
    other = np.maximum(rgb[:, :, 0], rgb[:, :, 2]).astype(np.float32)
    green = rgb[:, :, 1].astype(np.float32)
    excess = np.maximum(green - other, 0)

    # Smooth the transition between the opaque and transparent thresholds.
    opacity = np.clip((background - excess) / (background - foreground), 0, 1)
    opacity = opacity * opacity * (3 - 2 * opacity)
    alpha = np.rint(255 * opacity).astype(np.uint8)
    if feather:
        softened = Image.fromarray(alpha).filter(ImageFilter.GaussianBlur(feather))
        alpha = np.where(alpha == 0, 0, np.asarray(softened))

    rgba = np.empty((*alpha.shape, 4), dtype=np.uint8)
    rgba[:, :, :3] = rgb
    # Compression can spread green into pixels that the matte keeps opaque.
    rgba[:, :, 1] = np.rint(green - excess * despill).astype(np.uint8)
    rgba[:, :, 3] = alpha
    rgba[alpha == 0, :3] = 0
    return Image.fromarray(rgba)


def export_video(ffmpeg, video, destination, args):
    staging = Path(tempfile.mkdtemp(prefix=f".{video.stem}-", dir=destination.parent))
    count = 0
    command = [
        ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin", "-xerror",
        "-i", str(video), "-map", "0:V:0",
    ]
    if args.fps:
        command.extend(["-vf", f"fps={args.fps}:start_time=0:round=up"])
    command.extend(["-fps_mode", "passthrough", "-c:v", "ppm", "-f", "image2pipe", "pipe:1"])
    try:
        with subprocess.Popen(command, stdout=subprocess.PIPE) as decoder:
            try:
                for count, rgb in enumerate(read_frames(decoder.stdout), 1):
                    image = remove_green(
                        rgb, args.foreground, args.background, args.feather, args.despill
                    )
                    filename = staging / f"{video.stem}_{count:06d}.png"
                    with filename.open("xb") as output:
                        image.save(output, format="PNG", compress_level=3)
            except BaseException:
                decoder.kill()
                raise
            if decoder.wait():
                raise RuntimeError(f"FFmpeg could not finish decoding {video.name}.")

        if not count:
            raise RuntimeError(f"No video frames decoded from {video.name}.")
        if destination.exists():
            raise FileExistsError(f"Output folder already exists: {destination}")
        staging.rename(destination)
    except BaseException:
        print(f"Unfinished export kept in {staging}", flush=True)
        raise
    print(f"{video.name}: {count} frames -> {destination}", flush=True)


def prompt_for_fps(default):
    while True:
        answer = input(f"请输入每秒帧数（回车默认 {default}，0 导出全部原始帧）：").strip()
        if not answer:
            return default
        try:
            fps = int(answer)
            if fps >= 0:
                return fps
        except ValueError:
            pass
        print("请输入 0 或正整数，例如 5、12、24。")


def reserve_output_directory(source, fps):
    label = f"anim_{fps}fps" if fps else "anim_full_frames"
    output = source / label
    run = 1
    while True:
        try:
            output.mkdir()
            return output
        except FileExistsError:
            run += 1
            output = source / f"{label}_{run:02d}"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--input", type=Path, default=Path(__file__).resolve().parent,
        help="directory containing the videos (default: script directory)",
    )
    parser.add_argument(
        "--output", type=Path, help="new output location (default: anim inside input)",
    )
    parser.add_argument(
        "--fps", type=int, default=5, help="frames per second (default: 5; 0 keeps every frame)",
    )
    parser.add_argument(
        "--interactive", action="store_true",
        help="prompt for FPS and create a fresh output directory if --output is omitted",
    )
    parser.add_argument(
        "--foreground", type=float, default=24,
        help="green dominance at or below which pixels are opaque (default: 24)",
    )
    parser.add_argument(
        "--background", type=float, default=193,
        help="green dominance at or above which pixels are transparent (default: 193)",
    )
    parser.add_argument(
        "--feather", type=float, default=0.55, help="alpha feather radius in pixels (default: 0.55)",
    )
    parser.add_argument(
        "--despill", type=float, default=1, help="green spill suppression from 0 to 1 (default: 1)",
    )
    args = parser.parse_args()
    if args.fps < 0:
        parser.error("FPS must be non-negative.")
    if not 0 <= args.foreground < args.background <= 255:
        parser.error("Thresholds must satisfy 0 <= foreground < background <= 255.")
    if not 0 <= args.feather <= 10 or not 0 <= args.despill <= 1:
        parser.error("Feather must be between 0 and 10, and despill between 0 and 1.")

    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        parser.error("FFmpeg was not found on PATH.")
    if not args.input.is_dir():
        parser.error(f"Input directory not found: {args.input}")
    videos = sorted(
        path for path in args.input.iterdir()
        if path.is_file() and path.suffix.lower() in VIDEO_EXTENSIONS
    )
    if not videos:
        parser.error(f"No supported videos found in {args.input}")
    if len({video.stem.casefold() for video in videos}) != len(videos):
        parser.error("Two or more videos have the same base name.")

    if args.interactive:
        try:
            args.fps = prompt_for_fps(args.fps)
        except (EOFError, KeyboardInterrupt):
            parser.exit(1, "\n导出已取消。\n")
    output = args.output
    if output is None:
        if args.interactive:
            output = reserve_output_directory(args.input, args.fps)
        else:
            output = args.input / "anim"
    if args.interactive:
        print(f"输出目录：{output}", flush=True)
    for video in videos:
        destination = output / video.stem
        if destination.exists():
            parser.error(f"Output folder already exists: {destination}. Use --output for a new export.")
    output.mkdir(parents=True, exist_ok=True)
    for video in videos:
        try:
            export_video(ffmpeg, video, output / video.stem, args)
        except (OSError, ValueError, RuntimeError) as error:
            parser.exit(1, f"{video.name}: {error}\n")


if __name__ == "__main__":
    main()
