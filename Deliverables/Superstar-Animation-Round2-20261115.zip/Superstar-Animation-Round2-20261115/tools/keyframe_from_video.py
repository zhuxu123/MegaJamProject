"""Extract one real source frame. No resizing, trimming, morphing or synthesis."""
import argparse,subprocess
from pathlib import Path
from PIL import Image
p=argparse.ArgumentParser(__doc__)
p.add_argument('video',type=Path);p.add_argument('--frame',type=int,required=True,help='One-based decoded source frame')
p.add_argument('--out',type=Path,required=True)
a=p.parse_args()
if a.frame<1: p.error('frame must be positive')
if a.out.exists(): raise FileExistsError(a.out)
a.out.parent.mkdir(parents=True,exist_ok=True)
subprocess.run(['ffmpeg','-v','error','-nostdin','-n','-i',str(a.video),'-vf',f'select=eq(n\\,{a.frame-1})','-frames:v','1',str(a.out)],check=True)
with Image.open(a.out) as image:
    if image.size!=(640,640): raise ValueError('Source frame is not 640x640. Preserve original; explicitly prepare and record a compatible input.')
print(f'Extracted source frame {a.frame}; actual action-ready visual review still required: {a.out}')
