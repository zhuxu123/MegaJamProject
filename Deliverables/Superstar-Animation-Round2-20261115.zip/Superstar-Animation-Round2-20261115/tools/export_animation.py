"""Review source frames, trim the useful action, and export traceable 5 FPS RGBA sprites."""
import argparse
from bisect import bisect_left
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

import numpy as np
from PIL import Image, ImageDraw
from extract_green_screen import read_frames, remove_green

ROOT = Path(__file__).resolve().parents[1]


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def executable(name):
    value = shutil.which(name)
    if not value:
        raise RuntimeError(f'{name} not found on PATH')
    return value


def probe(video):
    command = [executable('ffprobe'), '-v', 'error', '-select_streams', 'v:0',
               '-show_frames', '-show_streams', '-show_entries',
               'frame=best_effort_timestamp_time:stream=width,height,avg_frame_rate,duration',
               '-of', 'json', str(video)]
    result = json.loads(subprocess.check_output(command))
    times = [float(f['best_effort_timestamp_time']) for f in result['frames']]
    if not times:
        raise ValueError('Video has no timestamped frames.')
    origin = times[0]
    times = [t-origin for t in times]
    if any(b <= a for a,b in zip(times,times[1:])):
        raise ValueError('Non-increasing source timestamps; normalize the source and record that operation.')
    stream = result['streams'][0]
    step = float(np.median(np.diff(times))) if len(times)>1 else 1/24
    duration = max(float(stream.get('duration') or 0),times[-1]+step)
    return {'times':times,'source_pts_origin':origin,'duration':duration,
            'width':stream['width'],'height':stream['height'], 'avg_frame_rate':stream['avg_frame_rate']}


def decode(video):
    command = [executable('ffmpeg'),'-hide_banner','-loglevel','error','-nostdin','-xerror',
               '-i',str(video),'-map','0:v:0','-fps_mode','passthrough','-c:v','ppm','-f','image2pipe','pipe:1']
    # tempfile prevents stderr pipe deadlocks on damaged input.
    with tempfile.TemporaryFile() as err:
        with subprocess.Popen(command,stdout=subprocess.PIPE,stderr=err) as process:
            try:
                for rgb in read_frames(process.stdout):
                    yield rgb
            except BaseException:
                process.kill()
                raise
            if process.wait():
                err.seek(0)
                raise RuntimeError(err.read().decode('utf-8','replace'))


def sheet(frames, labels, out, background=(245,245,245)):
    for page,start in enumerate(range(0,len(frames),24),1):
        batch=frames[start:start+24]
        canvas=Image.new('RGB',(4*170,math.ceil(len(batch)/4)*190),(220,220,220))
        draw=ImageDraw.Draw(canvas)
        for n,frame in enumerate(batch):
            im=frame.copy().convert('RGBA')
            im.thumbnail((160,160))
            tile=Image.new('RGBA',(160,160),(*background,255))
            tile.alpha_composite(im,((160-im.width)//2,(160-im.height)//2))
            x,y=(n%4)*170,(n//4)*190
            canvas.paste(tile.convert('RGB'),(x,y))
            draw.text((x+2,y+163),labels[start+n],fill=(0,0,0))
        canvas.save(out / f'contact_{page:02d}.jpg',quality=92)


def inspect(video, out):
    meta=probe(video)
    out.mkdir(parents=True,exist_ok=False)
    frames=[]
    for i,rgb in enumerate(decode(video)):
        im=Image.fromarray(rgb)
        im.save(out/f'source_{i+1:06d}.png')
        thumb=im.copy()
        thumb.thumbnail((160,160))
        frames.append(thumb)
    if len(frames)!=len(meta['times']):
        raise ValueError('Decoded frame count and timestamp count differ.')
    save(out/'source_timing.json',meta)
    labels=[f'{i+1:06d}  {t:.4f}s' for i,t in enumerate(meta['times'])]
    sheet(frames,labels,out)
    print(f'{len(frames)} source frames and timestamps -> {out}')


def nearest(times, value):
    k=bisect_left(times,value)
    candidates=[i for i in (k-1,k) if 0<=i<len(times)]
    return min(candidates,key=lambda i:abs(times[i]-value))


def select_samples(meta,cut):
    if cut.get('reviewed') is not True:
        raise ValueError('Source interval is not reviewed. Never assume a fixed intro length.')
    start,end=cut.get('start_seconds'),cut.get('end_seconds_exclusive')
    if not isinstance(start,(int,float)) or not isinstance(end,(int,float)):
        raise ValueError('Set measured start_seconds and end_seconds_exclusive.')
    if not (math.isfinite(start) and math.isfinite(end) and 0<=start<end<=meta['duration']+0.001):
        raise ValueError('Invalid cut interval.')
    duration=end-start
    if cut['loop']:
        count=round(duration*5)
        if count<4:
            raise ValueError('Loop must have at least four output frames.')
        if abs(count/5-duration)/duration>0.05+1e-9:
            raise ValueError('Loop timing adjustment exceeds 5%; select another complete cycle.')
        requested=[start+i*duration/count for i in range(count)]
    else:
        count=math.ceil(duration*5-1e-8)
        requested=[start+i/5 for i in range(count)]
    eligible=[i for i,t in enumerate(meta['times']) if start-1e-7<=t<end-1e-7]
    if len(eligible)<count:
        raise ValueError('Too few source frames for the requested 5 FPS interval.')
    eligible_times=[meta['times'][i] for i in eligible]
    selected=[eligible[nearest(eligible_times,t)] for t in requested]
    if len(set(selected))!=len(selected):
        raise ValueError('Duplicate samples; choose a better source interval or frame rate.')
    return selected,requested


def export(job,cut,out,args):
    if cut.get('loop') is not job['loop']:
        raise ValueError('cuts loop flag differs from job contract.')
    missing=set(job['events'])-set(cut.get('event_times',{}))
    if missing:
        raise ValueError('Record measured times for these events: '+', '.join(sorted(missing)))
    video=ROOT / cut['video']
    meta=probe(video)
    if [meta['width'],meta['height']]!=job['canvas']:
        raise ValueError('Source size differs from the agreed canvas.')
    selected,requested=select_samples(meta,cut)
    event_map={}
    sampled_times=[meta['times'][i] for i in selected]
    for name,t in cut['event_times'].items():
        if not isinstance(t,(int,float)) or not cut['start_seconds']<=t<cut['end_seconds_exclusive']:
            raise ValueError(f'Event {name} is outside the accepted cut.')
        index=nearest(sampled_times,t)
        event_map[name]={'source_seconds':t,'output_frame':index+1,
                         'sample_offset_seconds':sampled_times[index]-t}
    out.mkdir(parents=True,exist_ok=False)
    frames_dir=out/'frames'
    frames_dir.mkdir()
    needed=set(selected)
    images={}
    total=0
    for i,rgb in enumerate(decode(video)):
        total=i+1
        if i in needed:
            images[i]=remove_green(rgb,args.foreground,args.background,args.feather,args.despill)
    if total!=len(meta['times']) or len(images)!=len(selected):
        raise ValueError('Decoded source does not match probed frame timing.')
    frames=[images[i] for i in selected]
    mapping=[]
    for n,(source_index,frame,requested_time) in enumerate(zip(selected,frames,requested),1):
        name=f'{job["id"]}_{n:06d}.png'
        frame.save(frames_dir/name)
        alpha=np.asarray(frame)[:,:,3]
        visible=np.argwhere(alpha>32)
        bbox=None if len(visible)==0 else [int(visible[:,1].min()),int(visible[:,0].min()),int(visible[:,1].max()+1),int(visible[:,0].max()+1)]
        mapping.append({'file':'frames/'+name,'output_frame':n,'output_seconds':(n-1)/5,
                        'requested_source_seconds':requested_time,'source_frame':source_index+1,
                        'actual_source_seconds':meta['times'][source_index],'alpha_bbox':bbox})
    light=out/'qa_light';dark=out/'qa_dark'
    light.mkdir();dark.mkdir()
    labels=[f'{m["output_frame"]:06d} src {m["source_frame"]:06d}' for m in mapping]
    sheet(frames,labels,light,(245,245,245));sheet(frames,labels,dark,(28,28,35))
    previews=[]
    for frame in frames:
        bg=Image.new('RGBA',frame.size,(240,240,240,255))
        bg.alpha_composite(frame)
        previews.append(bg.convert('RGB'))
    kwargs={'loop':0} if job['loop'] else {}
    previews[0].save(out/'preview_5fps.gif',save_all=True,append_images=previews[1:],duration=200,
                     optimize=False,disposal=2,**kwargs)
    metadata={'id':job['id'],'fps':5,'frame_count':len(frames),'playback_seconds':len(frames)/5,
              'loop':job['loop'],'source':cut['video'],'source_sha256':hashlib.sha256(video.read_bytes()).hexdigest(),
              'cut':cut,'source_probe':{k:v for k,v in meta.items() if k!='times'},
              'source_interval_seconds':cut['end_seconds_exclusive']-cut['start_seconds'],
              'canvas':job['canvas'],'anchor_pixels':job['anchor'],'anchor_normalized':[job['anchor'][i]/job['canvas'][i] for i in (0,1)],
              'matte':{k:getattr(args,k) for k in ('foreground','background','feather','despill')},
              'events':event_map,'frame_mapping':mapping,'visual_review':'REQUIRED_NOT_AUTOMATICALLY_PASSED'}
    save(out/'animation.json',metadata)
    print(f'{job["id"]}: {len(frames)} frames at 5 FPS -> {out}')
    return metadata


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('inspect');p.add_argument('video',type=Path);p.add_argument('--out',type=Path,required=True)
    p=sub.add_parser('export');p.add_argument('id');p.add_argument('--out',type=Path,required=True)
    p.add_argument('--foreground',type=float,default=24);p.add_argument('--background',type=float,default=193)
    p.add_argument('--feather',type=float,default=0.55);p.add_argument('--despill',type=float,default=1)
    args=parser.parse_args()
    if args.command=='inspect':
        inspect(args.video,args.out)
    else:
        if not 0<=args.foreground<args.background<=255 or not 0<=args.feather<=10 or not 0<=args.despill<=1:
            parser.error('Invalid matte parameters.')
        matches=[j for j in read(ROOT/'config/jobs.json') if j['id']==args.id]
        if len(matches)!=1:
            parser.error('Unknown ID')
        export(matches[0],read(ROOT/'config/cuts.json')[args.id],args.out,args)


if __name__=='__main__':
    try:
        main()
    except (ValueError,OSError,RuntimeError,KeyError,subprocess.CalledProcessError) as exc:
        print(f'ERROR: {exc}',file=sys.stderr)
        sys.exit(1)
