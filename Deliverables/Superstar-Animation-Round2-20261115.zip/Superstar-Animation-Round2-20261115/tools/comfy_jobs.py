"""Portable ComfyUI I2V submission. No third-party HTTP client needed."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import urllib.error
import urllib.parse
import urllib.request
import uuid
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def request(url, path, data=None, content_type='application/json'):
    body = json.dumps(data).encode('utf-8') if isinstance(data, dict) else data
    req = urllib.request.Request(url.rstrip('/') + path, data=body,
                                 headers={'Content-Type': content_type} if body is not None else {})
    try:
        with urllib.request.urlopen(req, timeout=90) as response:
            return json.load(response)
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f'HTTP {exc.code}: {exc.read().decode("utf-8", "replace")}') from exc


def job_by_id(id):
    matches = [j for j in read(ROOT / 'config/jobs.json') if j['id'] == id]
    if len(matches) != 1:
        raise ValueError(f'Unknown or duplicate job ID: {id}')
    return matches[0]


def make_graph(job, attempt, image_name):
    graph = read(ROOT / 'workflows/h3_i2v_640_api.json')
    graph['114']['inputs']['image'] = image_name
    graph['105:104']['inputs']['prompt'] = (ROOT / job['prompt']).read_text(encoding='utf-8')
    graph['105:15']['inputs']['noise_seed'] = job['seed'] + attempt - 1
    graph['92']['inputs']['filename_prefix'] = f'video/superstar/{job["id"]}/attempt_{attempt:02d}'
    return graph


def preflight(url):
    graph = read(ROOT / 'workflows/h3_i2v_640_api.json')
    stats = request(url, '/system_stats')
    info = request(url, '/object_info')
    missing_nodes = sorted({n['class_type'] for n in graph.values()} - set(info))
    missing_models = []
    schema_issues = []
    for id, node in graph.items():
        meta = info.get(node['class_type'])
        if not meta:
            continue
        inputs = meta.get('input', {})
        specs = {**inputs.get('required', {}), **inputs.get('optional', {})}
        for field in ('unet_name', 'clip_name', 'vae_name'):
            if field in node['inputs']:
                available = specs.get(field, [None])[0]
                wanted = node['inputs'][field]
                if isinstance(available, list) and wanted not in available:
                    missing_models.append({'node': id, 'field': field, 'wanted': wanted,
                                           'related_available': [v for v in available if 'minimax' in str(v).lower()]})
        for field in inputs.get('required', {}):
            if field not in node['inputs']:
                schema_issues.append({'node': id, 'missing_required_input': field})
    result = {'checked_at': datetime.now(timezone.utc).isoformat(), 'url': url,
              'system_stats': stats, 'missing_nodes': missing_nodes,
              'missing_models': missing_models, 'schema_issues': schema_issues,
              'passed': not (missing_nodes or missing_models or schema_issues)}
    save(ROOT / 'runs/preflight.json', result)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if not result['passed']:
        raise RuntimeError('Preflight incomplete; resolve listed items before submitting.')
    return result


def upload(url, image_path, filename):
    boundary = '----H3Handoff' + uuid.uuid4().hex
    chunks = []
    for name, value in [('type', 'input'), ('subfolder', 'superstar_handoff'), ('overwrite', 'false')]:
        chunks.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n'.encode())
    chunks.append(f'--{boundary}\r\nContent-Disposition: form-data; name="image"; filename="{filename}"\r\nContent-Type: image/png\r\n\r\n'.encode())
    chunks.extend([image_path.read_bytes(), f'\r\n--{boundary}--\r\n'.encode()])
    response = request(url, '/upload/image', b''.join(chunks), f'multipart/form-data; boundary={boundary}')
    return '/'.join(part for part in [response.get('subfolder'), response['name']] if part)


def submit(args):
    from PIL import Image
    job = job_by_id(args.id)
    image_path = ROOT / job['first_frame']
    review = read(ROOT / 'config/first_frame_reviews.json')[args.id]
    if not all(review.get(k) is True for k in ('approved', 'identity_mapping_checked', 'action_ready')):
        raise ValueError('First-frame review not approved; inspect the actual image before editing review flags.')
    with Image.open(image_path) as im:
        if im.size != (640, 640) or im.format != 'PNG':
            raise ValueError('First frame must be a 640x640 PNG.')
    preflight(args.url)
    folder = ROOT / 'runs' / args.id / f'attempt_{args.attempt:02d}'
    folder.mkdir(parents=True, exist_ok=False)
    client = str(uuid.uuid4())
    filename = f'{args.id}_{digest(image_path)[:12]}.png'
    uploaded = upload(args.url, image_path, filename)
    graph = make_graph(job, args.attempt, uploaded)
    save(folder / 'submitted_api.json', graph)
    (folder / 'first_frame.png').write_bytes(image_path.read_bytes())
    (folder / 'prompt.txt').write_text(graph['105:104']['inputs']['prompt'], encoding='utf-8')
    record = {'id': args.id, 'attempt': args.attempt, 'url': args.url, 'client_id': client,
              'seed': graph['105:15']['inputs']['noise_seed'], 'first_frame_sha256': digest(image_path),
              'prompt_sha256': digest(folder / 'prompt.txt'), 'state': 'submitting',
              'created_at': datetime.now(timezone.utc).isoformat()}
    save(folder / 'record.json', record)
    response = request(args.url, '/prompt', {'prompt': graph, 'client_id': client})
    save(folder / 'submit_response.json', response)
    if response.get('node_errors') or not response.get('prompt_id'):
        raise RuntimeError(f'Submission rejected: {response}')
    record.update(prompt_id=response['prompt_id'], state='submitted')
    save(folder / 'record.json', record)
    print(json.dumps(record, ensure_ascii=False, indent=2))


def history(args):
    folder = ROOT / 'runs' / args.id / f'attempt_{args.attempt:02d}'
    record = read(folder / 'record.json')
    if not record.get('prompt_id'):
        raise ValueError('Submission ID unknown: inspect queue by client_id/prefix before retrying.')
    url = args.url or record['url']
    response = request(url, '/history/' + urllib.parse.quote(record['prompt_id']))
    save(folder / 'history.json', response)
    item = response.get(record['prompt_id'])
    if not item:
        queue = request(url, '/queue')
        save(folder / 'queue.json', queue)
        print('PENDING_OR_UNKNOWN: inspect saved queue; do not resubmit automatically.')
        return folder, url, None
    if item.get('status', {}).get('status_str') == 'error':
        raise RuntimeError('ComfyUI execution failed; see history.json for node errors.')
    return folder, url, item


def fetch(args):
    folder, url, item = history(args)
    if not item or not item.get('status', {}).get('completed'):
        raise RuntimeError('No completed history; not ready to download.')
    candidates = []
    def visit(value):
        if isinstance(value, dict):
            if value.get('filename', '').lower().endswith(('.mp4', '.webm', '.mov', '.mkv')):
                if value not in candidates:
                    candidates.append(value)
            for sub in value.values():
                visit(sub)
        elif isinstance(value, list):
            for sub in value:
                visit(sub)
    visit(item.get('outputs', {}).get('92', {}))
    if len(candidates) != 1:
        raise ValueError(f'Expected exactly one SaveVideo output, got {len(candidates)}; inspect history.')
    selected = candidates[0]
    suffix = Path(selected['filename']).suffix.lower()
    target = folder / ('source' + suffix)
    if target.exists():
        raise FileExistsError(f'{target} already exists; inspect it instead of downloading again.')
    query = urllib.parse.urlencode({k: selected.get(k, 'output' if k == 'type' else '') for k in ('filename','subfolder','type')})
    partial = folder / ('source' + suffix + '.part')
    with urllib.request.urlopen(url.rstrip('/') + '/view?' + query, timeout=180) as response, partial.open('xb') as out:
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            out.write(chunk)
    partial.rename(target)
    record = read(folder / 'record.json')
    record.update(state='downloaded_not_reviewed', video=target.relative_to(ROOT).as_posix(),
                  video_sha256=digest(target), comfy_output=selected)
    save(folder / 'record.json', record)
    print(target)
    print('Set the exact downloaded video path in cuts.json; do not assume the container is MP4.')


def verify_package():
    manifest = read(ROOT / 'MANIFEST.sha256.json')
    bad = [p for p, sha in manifest.items() if not (ROOT / p).is_file() or digest(ROOT / p) != sha]
    if bad:
        raise ValueError('Missing or changed files: ' + ', '.join(bad))
    print(f'PASS: {len(manifest)} packaged files verified.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('verify-package')
    pre = sub.add_parser('preflight')
    pre.add_argument('--url', default='http://127.0.0.1:8188')
    for name in ('submit', 'status', 'fetch', 'plan'):
        p = sub.add_parser(name)
        p.add_argument('id')
        p.add_argument('--attempt', type=int, default=1)
        p.add_argument('--url', default='http://127.0.0.1:8188' if name in ('submit','plan') else None)
    args = parser.parse_args()
    if getattr(args, 'attempt', 1) < 1:
        parser.error('attempt must be positive')
    if args.command == 'verify-package':
        verify_package()
    elif args.command == 'preflight':
        preflight(args.url)
    elif args.command == 'submit':
        submit(args)
    elif args.command == 'fetch':
        fetch(args)
    elif args.command == 'status':
        _, _, item = history(args)
        if item:
            print(json.dumps(item.get('status', {}), ensure_ascii=False, indent=2))
    elif args.command == 'plan':
        job = job_by_id(args.id)
        print(json.dumps(make_graph(job,args.attempt,'superstar_handoff/'+args.id+'.png'),ensure_ascii=False,indent=2))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, RuntimeError, KeyError) as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        sys.exit(1)
