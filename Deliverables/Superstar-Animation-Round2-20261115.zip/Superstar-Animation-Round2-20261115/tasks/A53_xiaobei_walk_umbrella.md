# A53_xiaobei_walk_umbrella · 拿伞走近

优先级：P0；剧情段：[38]；循环：True；朝向：right。

身份参考：`references/xiaobei.png`

依赖：无。baseline 从 current/clips.json 的 path 定位；REF 已由本批角色母版替代。

首帧提示词：`prompts/first_frame/A53_xiaobei_walk_umbrella.txt`；视频提示词：`prompts/video/A53_xiaobei_walk_umbrella.txt`。

道具：{'mode': 'attached', 'prop': 'umbrella', 'hand_coordinates': 'unmirrored 640x640 source pixels; one entry per frame'}。

起点：Standing facing screen right, with one empty hand curled at the closed umbrella handle contact point at waist height.

动作：Walk in place facing screen right carrying the same closed cream umbrella at waist height with its handle offered ahead.

表情：gentle calm willingness

需要记录的实际事件：['cycle_start', 'opposite_phase', 'cycle_return']。循环的 cycle_return 标注截断前最后一个有效相位样本；另在 cut.loop_end_seconds 记录被排除的同相位周期终点。

按 docs/交付契约.md 输出，不把当前临时走路或单帧待机算作本任务交付。
