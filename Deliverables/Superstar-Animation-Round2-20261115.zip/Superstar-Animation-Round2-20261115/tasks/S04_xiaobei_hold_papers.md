# S04_xiaobei_hold_papers · 抱资料站立待机循环 / 待机基线偏低

优先级：P0；剧情段：[14]；循环：True；朝向：right。

身份参考：`references/xiaobei.png`

依赖：['C05_xiaobei_rise_papers']。baseline 从 current/clips.json 的 path 定位；REF 已由本批角色母版替代。

首帧提示词：`prompts/first_frame/S04_xiaobei_hold_papers.txt`；视频提示词：`prompts/video/S04_xiaobei_hold_papers.txt`。

道具：{'mode': 'baked', 'prop': 'papers', 'hand_coordinates': 'unmirrored 640x640 source pixels; one entry per frame'}。

起点：Use the accepted standing end frame of C05, keeping exactly the same THREE-sheet stack against the chest and screen-right orientation.

动作：Begin very subtle rhythmic breathing at 0.00 seconds, remaining fully standing with both feet planted and both hands securely holding the same three-sheet stack. Repeat a smooth two-second idle cycle. Return to the same pose and motion phase at each boundary. Do not let papers drift, change count, fold or disappear. Do not start running. Match the corrected C05 endpoint and S02 ground baseline, while preserving the breathing loop.

表情：tense distressed eyes, no cheerful smile

需要记录的实际事件：['站姿呼吸循环', '资料始终被双手握住']。循环的 cycle_return 标注截断前最后一个有效相位样本；另在 cut.loop_end_seconds 记录被排除的同相位周期终点。

按 docs/交付契约.md 输出，不把当前临时走路或单帧待机算作本任务交付。
