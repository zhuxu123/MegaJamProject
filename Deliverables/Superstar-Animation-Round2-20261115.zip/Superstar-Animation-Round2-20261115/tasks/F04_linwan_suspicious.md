# F04_linwan_suspicious · 怀疑与动摇表情待机

优先级：P1；剧情段：[24, 25]；循环：True；朝向：right。

身份参考：`references/linwan.jpg`

依赖：['A27_linwan_mirror_idle']。baseline 从 current/clips.json 的 path 定位；REF 已由本批角色母版替代。

首帧提示词：`prompts/first_frame/F04_linwan_suspicious.txt`；视频提示词：`prompts/video/F04_linwan_suspicious.txt`。

道具：{'mode': 'none', 'prop': None, 'hand_coordinates': 'unmirrored 640x640 source pixels; one entry per frame'}。

起点：Use the seated mirror pose from A27, three-quarter turned left, with the suspicious expression already present.

动作：Maintain the specified facial expression throughout a subtle breathing loop. Natural small eye movement is allowed; keep the expression readable on every 5 fps frame. Never morph between emotions.

表情：one eyebrow raised, eyes tracking sideways, slightly uncertain parted lips

需要记录的实际事件：['cycle_start', 'opposite_phase', 'cycle_return']。循环的 cycle_return 标注截断前最后一个有效相位样本；另在 cut.loop_end_seconds 记录被排除的同相位周期终点。

按 docs/交付契约.md 输出，不把当前临时走路或单帧待机算作本任务交付。
