# E04_extra_m_walk · 原地走路循环 / 两侧着地基线

优先级：P0；剧情段：[7]；循环：True；朝向：right。

身份参考：`references/extra_m.jpg`

依赖：无。baseline 从 current/clips.json 的 path 定位；REF 已由本批角色母版替代。

首帧提示词：`prompts/first_frame/E04_extra_m_walk.txt`；视频提示词：`prompts/video/E04_extra_m_walk.txt`。

道具：{'mode': 'none', 'prop': None, 'hand_coordinates': 'unmirrored 640x640 source pixels; one entry per frame'}。

起点：Three-quarter view facing screen right, already at left-foot forward ground-contact phase in a walking cycle; preserve all character accessories and their hand assignment.

动作：Begin a steady in-place walk at 0.00 seconds. Alternate clear left and right foot contacts at a relaxed pace, with modest hip motion and natural arm movement allowed by held props. Keep a stationary screen-space root and constant screen-right facing direction. For the woman, the left hand keeps the clipboard and the right hand keeps the pen throughout; no swapping or new props. Complete repeated left-plus-right gait cycles, returning to the same foot phase and motion direction each cycle. Do not turn, stop, walk out of frame, or invent facial features. Correct both ground-contact phases to the E03 standing floor line; preserve flight and body bob, never snap each frame by bounding box.

表情：keep the intentionally featureless face

需要记录的实际事件：['左脚着地', '右脚着地', '完整左右步周期', '道具与无五官特征保持']。循环的 cycle_return 标注截断前最后一个有效相位样本；另在 cut.loop_end_seconds 记录被排除的同相位周期终点。

按 docs/交付契约.md 输出，不把当前临时走路或单帧待机算作本任务交付。
