# R01_linwan_peel_label · 扯下旧标签（替代撕整张照片）

优先级：P1；剧情段：[8]；循环：False；朝向：right。

身份参考：`references/linwan.jpg`

依赖：无。baseline 从 current/clips.json 的 path 定位；REF 已由本批角色母版替代。

首帧提示词：`prompts/first_frame/R01_linwan_peel_label.txt`；视频提示词：`prompts/video/R01_linwan_peel_label.txt`。

道具：{'mode': 'baked', 'prop': 'photo_label', 'hand_coordinates': 'unmirrored 640x640 source pixels; one entry per frame'}。Photo and peeling label are baked into this action. Deliver an intact photo/removed-label endpoint reference; runtime must hide duplicate photo props during this clip.

起点：Three-quarter view facing screen right, left hand steadies one intact contestant photo near eye height; right fingertips already pinch only the raised label corner. The photo is not torn.

动作：At frame zero the hand is already near eye level at the raised corner of a small old label on ONE intact contestant photo. Pinch only the peeling label, pull it off in one clear short motion and hold the removed strip. The photo remains whole. No tearing the photo into two pieces.

表情：concentrated disapproval, intent readable but whether helping or sabotaging remains ambiguous

需要记录的实际事件：['pinch_label', 'label_removed', 'photo_intact_end']。循环的 cycle_return 标注截断前最后一个有效相位样本；另在 cut.loop_end_seconds 记录被排除的同相位周期终点。

按 docs/交付契约.md 输出，不把当前临时走路或单帧待机算作本任务交付。
