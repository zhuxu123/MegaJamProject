# A43_suyao_kneel_accuse · 泪眼指认

优先级：P1；剧情段：[30, 31]；循环：True；朝向：left。

身份参考：`references/suyao.jpg`

依赖：['A42_suyao_fake_fall']。baseline 从 current/clips.json 的 path 定位；REF 已由本批角色母版替代。

首帧提示词：`prompts/first_frame/A43_suyao_kneel_accuse.txt`；视频提示词：`prompts/video/A43_suyao_kneel_accuse.txt`。

道具：{'mode': 'none', 'prop': None, 'hand_coordinates': 'unmirrored 640x640 source pixels; one entry per frame'}。

起点：The exact A42 kneeling seated endpoint; one hand covers the shoulder and the other is ready to point left. Preserve the low body silhouette and the original standing body scale.

动作：Remain in the kneeling endpoint of A42, one hand over the shoulder, the other pointing toward screen left; subtle breathing without changing the pointing target.

表情：watery eyes and staged frightened grievance

需要记录的实际事件：['cycle_start', 'opposite_phase', 'cycle_return']。循环的 cycle_return 标注截断前最后一个有效相位样本；另在 cut.loop_end_seconds 记录被排除的同相位周期终点。

按 docs/交付契约.md 输出，不把当前临时走路或单帧待机算作本任务交付。
