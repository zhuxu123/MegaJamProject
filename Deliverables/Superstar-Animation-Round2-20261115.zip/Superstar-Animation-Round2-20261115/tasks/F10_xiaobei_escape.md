# F10_xiaobei_escape · 逃离不安表情待机

优先级：P1；剧情段：[15]；循环：True；朝向：right。

身份参考：`references/xiaobei.png`

依赖：['S04_xiaobei_hold_papers']。baseline 从 current/clips.json 的 path 定位；REF 已由本批角色母版替代。

首帧提示词：`prompts/first_frame/F10_xiaobei_escape.txt`；视频提示词：`prompts/video/F10_xiaobei_escape.txt`。

道具：{'mode': 'baked', 'prop': 'papers', 'hand_coordinates': 'unmirrored 640x640 source pixels; one entry per frame'}。

起点：Use the approved S04 standing pose holding papers against the torso, including the same paper silhouette. Expression is fully established at frame zero.

动作：Maintain the specified facial expression throughout a subtle breathing loop. Natural small eye movement is allowed; keep the expression readable on every 5 fps frame. Never morph between emotions.

表情：frightened lowered eyes, drawn-in shoulders, pressed lips

需要记录的实际事件：['cycle_start', 'opposite_phase', 'cycle_return']。循环的 cycle_return 标注截断前最后一个有效相位样本；另在 cut.loop_end_seconds 记录被排除的同相位周期终点。

按 docs/交付契约.md 输出，不把当前临时走路或单帧待机算作本任务交付。
