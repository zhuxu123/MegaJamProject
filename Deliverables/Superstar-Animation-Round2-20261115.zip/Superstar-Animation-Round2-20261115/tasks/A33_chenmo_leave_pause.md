# A33_chenmo_leave_pause · 后退离开停顿

优先级：P1；剧情段：[26]；循环：False；朝向：right。

身份参考：`references/masters/chenmo.png`

依赖：['baseline:M_chenmo']。baseline 从 current/clips.json 的 path 定位；REF 已由本批角色母版替代。

首帧提示词：`prompts/first_frame/A33_chenmo_leave_pause.txt`；视频提示词：`prompts/video/A33_chenmo_leave_pause.txt`。

道具：{'mode': 'none', 'prop': None, 'hand_coordinates': 'unmirrored 640x640 source pixels; one entry per frame'}。

起点：Standing in a grounded action-ready pose, three-quarter view facing screen right.

动作：Take one short backward step, turn toward screen left, initiate a walk, then pause and glance slightly back.

表情：thoughtful reserved hesitation

需要记录的实际事件：['action_onset', 'main_event', 'settled_end']。循环的 cycle_return 标注截断前最后一个有效相位样本；另在 cut.loop_end_seconds 记录被排除的同相位周期终点。

按 docs/交付契约.md 输出，不把当前临时走路或单帧待机算作本任务交付。
