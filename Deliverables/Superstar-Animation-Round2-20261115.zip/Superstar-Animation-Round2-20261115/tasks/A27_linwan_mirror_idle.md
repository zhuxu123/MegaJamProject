# A27_linwan_mirror_idle · 镜前坐姿

优先级：P1；剧情段：[24, 25, 27]；循环：True；朝向：right。

身份参考：`references/linwan.jpg`

依赖：无。baseline 从 current/clips.json 的 path 定位；REF 已由本批角色母版替代。

首帧提示词：`prompts/first_frame/A27_linwan_mirror_idle.txt`；视频提示词：`prompts/video/A27_linwan_mirror_idle.txt`。

道具：{'mode': 'none', 'prop': None, 'hand_coordinates': 'unmirrored 640x640 source pixels; one entry per frame'}。

起点：Already seated on an invisible stool, three-quarter back view toward screen right, feet at the shared floor line, no standing-to-sitting introduction.

动作：Sit on an invisible fixed-height stool facing three-quarter away toward screen right; breathe subtly with feet at the established floor line. No stool or mirror baked into the sprite.

表情：quiet guarded face, eyes directed toward an offscreen mirror

需要记录的实际事件：['cycle_start', 'opposite_phase', 'cycle_return']。循环的 cycle_return 标注截断前最后一个有效相位样本；另在 cut.loop_end_seconds 记录被排除的同相位周期终点。

按 docs/交付契约.md 输出，不把当前临时走路或单帧待机算作本任务交付。
