# C03_xiaobei_fall_scatter · 跌倒散落资料：修正慌乱表情与终点衔接

优先级：P0；剧情段：[10]；循环：False；朝向：right。

身份参考：`references/xiaobei.png`

依赖：['baseline:C02_xiaobei_jog_papers']。baseline 从 current/clips.json 的 path 定位；REF 已由本批角色母版替代。

首帧提示词：`prompts/first_frame/C03_xiaobei_fall_scatter.txt`；视频提示词：`prompts/video/C03_xiaobei_fall_scatter.txt`。

道具：{'mode': 'baked', 'prop': 'papers', 'hand_coordinates': 'unmirrored 640x640 source pixels; one entry per frame'}。

起点：Match the final running pose of current C02, carrying papers, facing screen right.

动作：Lose balance once and fall into a low kneeling pose as the papers scatter. Eyes widen, brows lift and the mouth opens in a short startled gasp BEFORE the fall; no smile. End at the compatible low pose of current A16 frame zero and C04 frame zero.

表情：startled panic, then anxious embarrassment

需要记录的实际事件：['action_onset', 'loss_of_balance', 'ground_contact', 'settled_end']。循环的 cycle_return 标注截断前最后一个有效相位样本；另在 cut.loop_end_seconds 记录被排除的同相位周期终点。

按 docs/交付契约.md 输出，不把当前临时走路或单帧待机算作本任务交付。
