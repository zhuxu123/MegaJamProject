# A11_linwan_open_umbrella · 撑开雨伞

优先级：P0；剧情段：[5]；循环：False；朝向：right。

身份参考：`references/linwan.jpg`

依赖：['A09_linwan_take_umbrella']。baseline 从 current/clips.json 的 path 定位；REF 已由本批角色母版替代。

首帧提示词：`prompts/first_frame/A11_linwan_open_umbrella.txt`；视频提示词：`prompts/video/A11_linwan_open_umbrella.txt`。

道具：{'mode': 'baked', 'prop': 'umbrella', 'hand_coordinates': 'unmirrored 640x640 source pixels; one entry per frame'}。Deliver the opening umbrella as part of this baked clip, plus a clean final open-umbrella reference and final hand anchor. Runtime must hide separate umbrella for this clip and restore it for A12. Do not leave the closed umbrella static while the hand opens nothing.

起点：Standing in a grounded action-ready pose, three-quarter view facing screen right.

动作：Starting with the closed cream umbrella in hand, raise it beside the shoulder and open it once above the head. Keep the entire canopy inside the frame.

表情：neutral detached expression

需要记录的实际事件：['action_onset', 'main_event', 'settled_end']。循环的 cycle_return 标注截断前最后一个有效相位样本；另在 cut.loop_end_seconds 记录被排除的同相位周期终点。

按 docs/交付契约.md 输出，不把当前临时走路或单帧待机算作本任务交付。
