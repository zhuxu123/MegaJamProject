# A06_actress_leave_bowed · 低头离开

优先级：P0；剧情段：[3]；循环：True；朝向：right。

身份参考：`references/masters/actress.png`

依赖：['baseline:M_actress']。baseline 从 current/clips.json 的 path 定位；REF 已由本批角色母版替代。

首帧提示词：`prompts/first_frame/A06_actress_leave_bowed.txt`；视频提示词：`prompts/video/A06_actress_leave_bowed.txt`。

道具：{'mode': 'none', 'prop': None, 'hand_coordinates': 'unmirrored 640x640 source pixels; one entry per frame'}。

起点：Standing in a grounded action-ready pose, three-quarter view facing screen left.

动作：Walk in place facing screen left with the chin lowered, shoulders drawn in and arms close to the body.

表情：subdued frightened eyes looking downward

需要记录的实际事件：['cycle_start', 'opposite_phase', 'cycle_return']。循环的 cycle_return 标注截断前最后一个有效相位样本；另在 cut.loop_end_seconds 记录被排除的同相位周期终点。

按 docs/交付契约.md 输出，不把当前临时走路或单帧待机算作本任务交付。
