# F13_suyao_shock · 错愕表情待机

优先级：P0；剧情段：[17]；循环：True；朝向：left。

身份参考：`references/suyao.jpg`

依赖：['baseline:C08_suyao_fall_kneel']。baseline 从 current/clips.json 的 path 定位；REF 已由本批角色母版替代。

首帧提示词：`prompts/first_frame/F13_suyao_shock.txt`；视频提示词：`prompts/video/F13_suyao_shock.txt`。

道具：{'mode': 'none', 'prop': None, 'hand_coordinates': 'unmirrored 640x640 source pixels; one entry per frame'}。

起点：Use exactly the LAST frame of current C08_suyao_fall_kneel: low kneeling silhouette, facing screen left. Preserve its low head height, body scale, dress and foot registration. Never use retired S05.

动作：Maintain the specified facial expression throughout a subtle breathing loop. Natural small eye movement is allowed; keep the expression readable on every 5 fps frame. Never morph between emotions.

表情：suddenly widened eyes, interrupted smile and slightly open mouth

需要记录的实际事件：['cycle_start', 'opposite_phase', 'cycle_return']。循环的 cycle_return 标注截断前最后一个有效相位样本；另在 cut.loop_end_seconds 记录被排除的同相位周期终点。

按 docs/交付契约.md 输出，不把当前临时走路或单帧待机算作本任务交付。
