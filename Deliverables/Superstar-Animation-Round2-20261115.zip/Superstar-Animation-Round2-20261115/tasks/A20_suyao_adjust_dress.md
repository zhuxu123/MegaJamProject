# A20_suyao_adjust_dress · 整理裙摆重新甜笑

优先级：P1；剧情段：[19]；循环：False；朝向：left。

身份参考：`references/suyao.jpg`

依赖：['C09_suyao_rise']。baseline 从 current/clips.json 的 path 定位；REF 已由本批角色母版替代。

首帧提示词：`prompts/first_frame/A20_suyao_adjust_dress.txt`；视频提示词：`prompts/video/A20_suyao_adjust_dress.txt`。

道具：{'mode': 'none', 'prop': None, 'hand_coordinates': 'unmirrored 640x640 source pixels; one entry per frame'}。

起点：Match the exact last frame of current C09_suyao_rise, standing and facing screen left.

动作：Begin standing at the C09 endpoint; smooth the short dress hem with both hands, straighten the torso and bring back a social smile.

表情：visible progression from shame and resentment to a controlled sweet smile

需要记录的实际事件：['action_onset', 'main_event', 'settled_end']。循环的 cycle_return 标注截断前最后一个有效相位样本；另在 cut.loop_end_seconds 记录被排除的同相位周期终点。

按 docs/交付契约.md 输出，不把当前临时走路或单帧待机算作本任务交付。
