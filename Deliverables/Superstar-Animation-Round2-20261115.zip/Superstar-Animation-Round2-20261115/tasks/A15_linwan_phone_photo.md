# A15_linwan_phone_photo · 拿手机偷拍

优先级：P0；剧情段：[6]；循环：False；朝向：right。

身份参考：`references/linwan.jpg`

依赖：无。baseline 从 current/clips.json 的 path 定位；REF 已由本批角色母版替代。

首帧提示词：`prompts/first_frame/A15_linwan_phone_photo.txt`；视频提示词：`prompts/video/A15_linwan_phone_photo.txt`。

道具：{'mode': 'attached', 'prop': 'phone', 'hand_coordinates': 'unmirrored 640x640 source pixels; one entry per frame'}。

起点：Standing in a grounded action-ready pose, three-quarter view facing screen right.

动作：Raise a charcoal smartphone vertically from chest height to a photographing position, aim to screen left, tap the shutter once and lower slightly.

表情：focused guarded eyes, no smile

需要记录的实际事件：['action_onset', 'main_event', 'settled_end']。循环的 cycle_return 标注截断前最后一个有效相位样本；另在 cut.loop_end_seconds 记录被排除的同相位周期终点。

按 docs/交付契约.md 输出，不把当前临时走路或单帧待机算作本任务交付。
