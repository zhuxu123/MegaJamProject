# F18_limou_cold · 阴冷安抚表情待机

优先级：P1；剧情段：[22]；循环：True；朝向：right。

身份参考：`references/masters/limou.png`

依赖：['baseline:M_limou']。baseline 从 current/clips.json 的 path 定位；REF 已由本批角色母版替代。

首帧提示词：`prompts/first_frame/F18_limou_cold.txt`；视频提示词：`prompts/video/F18_limou_cold.txt`。

道具：{'mode': 'none', 'prop': None, 'hand_coordinates': 'unmirrored 640x640 source pixels; one entry per frame'}。

起点：Use the exact body, feet, costume, camera and canvas registration of this character's approved idle. The target facial expression is already fully present at frame zero.

动作：Maintain the specified facial expression throughout a subtle breathing loop. Natural small eye movement is allowed; keep the expression readable on every 5 fps frame. Never morph between emotions.

表情：a reassuring half-smile contradicted by cold narrowed calculating eyes

需要记录的实际事件：['cycle_start', 'opposite_phase', 'cycle_return']。循环的 cycle_return 标注截断前最后一个有效相位样本；另在 cut.loop_end_seconds 记录被排除的同相位周期终点。

按 docs/交付契约.md 输出，不把当前临时走路或单帧待机算作本任务交付。
